# The Real Team 3 - AntennaPod [![Build Status](https://travis-ci.com/joeyfallu/AntennaPodSoen390.svg?token=oKkQVojzqjYzmWn1EJrq&branch=master)](https://travis-ci.com/joeyfallu/AntennaPodSoen390)

This is a copy of the official repository of AntennaPod, the easy-to-use, flexible and open-source podcast manager for Android.
- [Wiki](https://github.com/joeyfallu/AntennaPodSoen390/wiki)
- [Coding Style](https://github.com/ribot/android-guidelines/blob/master/project_and_code_guidelines.md)
- [Code Review Policy](https://github.com/joeyfallu/AntennaPodSoen390/wiki/Code-Review-Policy)

[<img src="https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png"
      alt="Get it on Google Play"
      height="90">](https://play.google.com/store/apps/details?id=de.danoeh.antennapod)
[<img src="https://f-droid.org/badge/get-it-on.png"
      alt="Get it on F-Droid"
      height="90">](https://f-droid.org/app/de.danoeh.antennapod)

## Feedback
You can use the [AntennaPod Google Group](https://groups.google.com/forum/#!forum/antennapod) for discussions about the app.

Bug reports and feature requests can be submitted [here](https://github.com/AntennaPod/AntennaPod/issues) (please read the [instructions](https://github.com/AntennaPod/AntennaPod/blob/master/CONTRIBUTING.md) on how to report a bug and how to submit a feature request first!).

## Help test AntennaPod
AntennaPod has many users and we don't want them to run into trouble when we add a new feature. It's important that we have a significant group test our app, so that we know all possible combinations of phones, Android versions and use cases work as expected. Check out our wiki how to join our [Alpha and Beta testing programmes](https://github.com/AntennaPod/AntennaPod/wiki/Help-test-AntennaPod)!

## Nightly Builds

There are APKs available for every branch that is actively worked on. Please note that these might be very unstable versions of the app, which can break your current installation. Install them at your own risk!

Click [here](https://www.dropbox.com/sh/lzfd640z63qz3fr/AACyxTF1ygR9wMlPLPwVGIUKa?dl=0) to get to the nightly builds folder.
    
## License

AntennaPod is licensed under the MIT License. You can find the license text in the LICENSE file.

## Translating AntennaPod
If you want to translate AntennaPod into another language, you can visit the [Transifex project page](https://www.transifex.com/antennapod/antennapod/).


## Building AntennaPod

Information on how to build AntennaPod can be found in the [Wiki](https://github.com/AntennaPod/AntennaPod/wiki/Building-AntennaPod).

