package de.danoeh.antennapod.core.storage;

import android.test.AndroidTestCase;
import android.util.Log;

import junit.framework.TestCase;

import java.io.File;
import java.util.HashMap;

import static de.danoeh.antennapod.core.util.flattr.FlattrServiceCreator.TAG;


public class GenreStorageTest extends AndroidTestCase {

    public void testSaveGenreStorage() throws Exception
    {
        GenreStorage.loadGenres(getContext());
        File tmp = new File(getContext().getFilesDir(), "genreStorage");
        if(tmp.exists())
        {
            tmp.delete();
        }

        HashMap<String, int[]> testGenres = new HashMap<String, int[]>();
        Log.d(TAG,"element found: ");
        int a[] ={1111,2222,3333};
        int b[] ={7777,2332,3333};
        int c[] ={1111,2442};
        testGenres.put("podcast1",a);
        testGenres.put("podcast2",b);
        testGenres.put("podcast3",c);

        GenreStorage.saveGenre(testGenres, getContext());


        File save = new File(getContext().getFilesDir(),"genreStorage");
        assertEquals(true, save.exists() );
        assertEquals( true,save.isFile());
        assertEquals(true, (save.getTotalSpace()>0));

    }

    public void testLoadSaveGenreStorage()
    {
        GenreStorage.loadGenres(getContext());
        File tmp = new File(getContext().getFilesDir(), "genreStorage");
        if(tmp.exists())
        {
            tmp.delete();
        }

        HashMap<String, int[]> testGenres = new HashMap<String, int[]>();
        Log.d(TAG,"element found: ");
        int a[] ={1111,2222,3333};
        int b[] ={7777,2332,3333};
        int c[] ={1111,2442};
        testGenres.put("podcast1",a);
        testGenres.put("podcast2",b);
        testGenres.put("podcast3",c);

        GenreStorage.saveGenre(testGenres, getContext());

        HashMap<String, int[]> loaded = GenreStorage.loadGenres(getContext());

        boolean testEquals = true;

        int[]a1= loaded.get("podcast1");
        int[]b1= loaded.get("podcast2");
        int[]c1= loaded.get("podcast3");

        if(a[0]!=a1[0]){testEquals=false;}
        if(a[1]!=a1[1]){testEquals=false;}
        if(a[2]!=a1[2]){testEquals=false;}

        if(b[0]!=b1[0]){testEquals=false;}
        if(b[1]!=b1[1]){testEquals=false;}
        if(b[2]!=b1[2]){testEquals=false;}

        if(c[0]!=c1[0]){testEquals=false;}
        if(c[1]!=c1[1]){testEquals=false;}

        assertEquals(true,testEquals);
    }

}