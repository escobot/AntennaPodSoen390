package de.danoeh.antennapod.core.playlist;

import junit.framework.TestCase;

import java.util.ArrayList;

import de.danoeh.antennapod.core.feed.FeedItem;

import static org.mockito.Mockito.*;

public class PlaylistTest extends TestCase {

    public void testGetName() throws Exception {
        Playlist playlist = new Playlist("test");

        assertEquals("test", playlist.getName());
    }
    public void testAddPodcast(){
        FeedItem mockFeedItem = mock(FeedItem.class);
        when(mockFeedItem.getId()).thenReturn((long) 12345);

        Playlist playlist = new Playlist("test");
        playlist.addPodcast(mockFeedItem);

        ArrayList<Long> podcasts = playlist.getPodcasts();

        //test add the podcast to the playlist
        assertEquals(true, podcasts.contains(mockFeedItem.getId()));
        //if podcast is already in playlist, don't add again.
        assertEquals(false, playlist.addPodcast(mockFeedItem));
    }

    public void testRemovePodcast(){
        FeedItem mock1 = mock(FeedItem.class);
        FeedItem mock2 = mock(FeedItem.class);
        FeedItem mock3 = mock(FeedItem.class);
        when(mock1.getId()).thenReturn((long) 12345);
        when(mock2.getId()).thenReturn((long) 12346);
        when(mock3.getId()).thenReturn((long) 12347);

        Playlist playlist = new Playlist("test");
        playlist.addPodcast(mock1);
        playlist.addPodcast(mock2);
        playlist.addPodcast(mock3);

        playlist.removePodcast(mock2.getId());

        ArrayList<Long> podcasts = playlist.getPodcasts();

        assertEquals(true,podcasts.contains(mock1.getId()));
        assertEquals(false,podcasts.contains(mock2.getId()));
        assertEquals(true,podcasts.contains(mock3.getId()));
    }
}