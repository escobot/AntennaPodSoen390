package de.danoeh.antennapod.core.tests.util;


import android.test.AndroidTestCase;

import java.util.Calendar;
import java.util.Date;

import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.util.comparator.FeedItemLastPlayedComparator;


public class FeedItemLastPlayedComparatorTest extends AndroidTestCase {

    public void testEquals() {
        // create 2 feed items with the same last played date
        FeedItem feedItem1 = new FeedItem();
        FeedItem feedItem2 = new FeedItem();
        Date today = new Date();
        feedItem1.setLastPlayed(today);
        feedItem2.setLastPlayed(today);

        FeedItemLastPlayedComparator comparator = new FeedItemLastPlayedComparator();
        assertEquals(comparator.compare(feedItem1, feedItem2), 0);
    }

    public void testLessThan() {
        // create 2 feed items with the same different dates
        FeedItem feedItem1 = new FeedItem();
        FeedItem feedItem2 = new FeedItem();
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DAY_OF_YEAR,-1);
        Date yesterday = cal.getTime();
        feedItem1.setLastPlayed(yesterday);
        feedItem2.setLastPlayed(today);

        // feedItem1 lastPlayedDate before the feedItem2
        FeedItemLastPlayedComparator comparator = new FeedItemLastPlayedComparator();
        assertEquals(comparator.compare(feedItem1, feedItem2), 1);
    }

    public void testGreaterThan() {
        // create 2 feed items with the same different dates
        FeedItem feedItem1 = new FeedItem();
        FeedItem feedItem2 = new FeedItem();
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DAY_OF_YEAR,-1);
        Date yesterday = cal.getTime();
        feedItem1.setLastPlayed(today);
        feedItem2.setLastPlayed(yesterday);

        // feedItem1 lastPlayedDate after the feedItem2
        FeedItemLastPlayedComparator comparator = new FeedItemLastPlayedComparator();
        assertEquals(comparator.compare(feedItem1, feedItem2), -1);
    }
}
