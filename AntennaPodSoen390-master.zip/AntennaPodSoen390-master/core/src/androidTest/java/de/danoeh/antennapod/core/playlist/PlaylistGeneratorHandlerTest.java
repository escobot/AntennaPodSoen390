package de.danoeh.antennapod.core.playlist;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.danoeh.antennapod.core.feed.Feed;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PlaylistGeneratorHandlerTest extends TestCase {

    private PlaylistGeneratorHandler playlistGeneratorHandler;
    private HashMap<String, int[]> genresStored = new HashMap<>();
    private List<Feed> mockFeeds = new ArrayList<>();
    private Feed artPodcast = mock(Feed.class);
    private Feed artPodcast2 = mock(Feed.class);
    private Feed foodPodcast = mock(Feed.class);
    private Feed sciencePodcast = mock(Feed.class);
    private List<Integer> artCodes = new ArrayList<>();
    private List<Integer> foodCodes = new ArrayList<>();
    private List<Integer> comedyCodes = new ArrayList<>();

    @Override
    public void setUp() throws Exception {
        super.setUp();
        //See arrays.xml for correct genre codes
        genresStored.put("Art", new int[]{1301,1401,1402});
        genresStored.put("Art2", new int[]{1301,1406,1459});
        genresStored.put("Food", new int[]{1306});
        genresStored.put("Science", new int[]{1477,1479});

        mockFeeds.add(artPodcast);
        mockFeeds.add(artPodcast2);
        mockFeeds.add(foodPodcast);
        mockFeeds.add(sciencePodcast);

        artCodes.add(1301);
        artCodes.add(1401);
        artCodes.add(1402);
        artCodes.add(1405);
        artCodes.add(1406);
        artCodes.add(1459);

        foodCodes.add(1306);

        comedyCodes.add(1303);

        when(artPodcast.getTitle()).thenReturn("Art");
        when(artPodcast2.getTitle()).thenReturn("Art2");
        when(foodPodcast.getTitle()).thenReturn("Food");
        when(sciencePodcast.getTitle()).thenReturn("Science");

        playlistGeneratorHandler = new PlaylistGeneratorHandler(genresStored);
        playlistGeneratorHandler.setSubscribedFeedsForTestingOnly(mockFeeds);
    }

    public void testingMultiplePodcastsOfSameGenreFound() throws Exception {
        List<Feed> sortedFeeds = playlistGeneratorHandler.setSortedFeeds(artCodes);

        assertTrue(sortedFeeds.contains(artPodcast));
        assertTrue(sortedFeeds.contains(artPodcast2));
        assertFalse(sortedFeeds.contains(foodPodcast));
        assertFalse(sortedFeeds.contains(sciencePodcast));
    }

    public void testingOnePodcastOfSpecificGenreFound() throws Exception {
        List<Feed> sortedFeeds = playlistGeneratorHandler.setSortedFeeds(foodCodes);

        assertFalse(sortedFeeds.contains(artPodcast));
        assertFalse(sortedFeeds.contains(artPodcast2));
        assertTrue(sortedFeeds.contains(foodPodcast));
        assertFalse(sortedFeeds.contains(sciencePodcast));
    }

    public void testingNoPodcastsFound() throws Exception {
        List<Feed> sortedFeeds = playlistGeneratorHandler.setSortedFeeds(comedyCodes);

        assertFalse(sortedFeeds.contains(artPodcast));
        assertFalse(sortedFeeds.contains(artPodcast2));
        assertFalse(sortedFeeds.contains(foodPodcast));
        assertFalse(sortedFeeds.contains(sciencePodcast));
    }
}