package de.danoeh.antennapod.core.storage;

import android.test.AndroidTestCase;
import java.io.File;
import java.util.ArrayList;

import de.danoeh.antennapod.core.playlist.Playlist;


public class PlaylistStorageTest extends AndroidTestCase {

    public void testSavePlaylists() throws Exception {
        //Make sure saveFile doesn't previously exist
        File tmp = new File(getContext().getFilesDir(),"playlistStorage");
        if(tmp.exists())
            tmp.delete();

        //Create arrayList to be saved
        ArrayList<Playlist> playlists = new ArrayList<>();

        Playlist playlist1 = new Playlist("Test1");
        Playlist playlist2 = new Playlist("Test2");
        Playlist playlist3 = new Playlist("Test3");

        playlists.add(playlist1);
        playlists.add(playlist2);
        playlists.add(playlist3);

        //Test here
        PlaylistStorage.savePlaylists(playlists,getContext());

        File save = new File(getContext().getFilesDir(),"playlistStorage");
        assertEquals(true, save.exists() && save.isFile() && (save.getTotalSpace() > 0));
    }

    public void testLoadPlaylists() throws Exception {
        //Create arrayList to be saved
        ArrayList<Playlist> playlists = new ArrayList<>();

        Playlist playlist1 = new Playlist("Test1");
        Playlist playlist2 = new Playlist("Test2");
        Playlist playlist3 = new Playlist("Test3");

        playlists.add(playlist1);
        playlists.add(playlist2);
        playlists.add(playlist3);
        //If savePlaylists doesn't pass, this test will also fail.
        PlaylistStorage.savePlaylists(playlists,getContext());

        //Test
        ArrayList<Playlist> loadedPlaylists = PlaylistStorage.loadPlaylists(getContext());

        /*
        equality boolean will be used to check multiple cases
         */
        boolean equality = true;
        if(playlists.size() != loadedPlaylists.size())
            equality = false;
        else {
            for(int i=0; i<playlists.size();i++){
                if(!(playlists.get(i).getName().equals(loadedPlaylists.get(i).getName()))){
                    equality = false;
                }
            }
        }

        assertEquals(true,equality);
    }

}