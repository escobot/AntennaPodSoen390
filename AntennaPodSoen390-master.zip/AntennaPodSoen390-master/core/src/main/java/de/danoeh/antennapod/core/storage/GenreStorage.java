package de.danoeh.antennapod.core.storage;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;


public class GenreStorage {
    final static String FILENAME = "genreStorage";
    static File saveFile;

    public static void saveGenre(HashMap genre, Context context){
        if(saveFile != null) {
            if (!saveFile.exists()) {
                saveFile = new File(context.getFilesDir(), FILENAME);
            }
        }
        try{
            FileOutputStream fos = new FileOutputStream(saveFile);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(genre);
            System.out.println("Saved genres successfully");
            oos.close();
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    public static HashMap loadGenres(Context context){
        HashMap result = null;
        saveFile = new File(context.getFilesDir(),FILENAME);
        if(!saveFile.exists()){
            result = new HashMap();
            System.out.println("Savefile doesn't exist, creating new hashmap");
        }else {
            try{
                FileInputStream fis = new FileInputStream(saveFile);
                ObjectInputStream ois = new ObjectInputStream(fis);
                result = (HashMap) ois.readObject();
                if(result == null){
                    System.out.println("Savefile contains null hashmap. Initializing hashmap");
                    result = new HashMap();
                }
                System.out.println("Storage loaded genres successfully\nSize: " + result.size());
                ois.close();
                return result;
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return result;
    }

    public static boolean wipeGenreSaveFile(Context context){
        boolean deleted = false;
        if(saveFile == null){
            saveFile = new File(context.getFilesDir(), FILENAME);
        }
        try{
            deleted = saveFile.delete();
            return deleted;
        }catch(Exception e){
            e.printStackTrace();
        }
        return deleted;
    }
}
