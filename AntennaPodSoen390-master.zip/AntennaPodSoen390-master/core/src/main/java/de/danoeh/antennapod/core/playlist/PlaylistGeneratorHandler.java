package de.danoeh.antennapod.core.playlist;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.storage.DBReader;

public class PlaylistGeneratorHandler {

    private DBReader.NavDrawerData subscriptions;
    private List<Feed> subscribedPodcasts;
    private HashMap<String, int[]> genresStored = new HashMap<>();
    private List<Feed> sortedFeeds;

    public PlaylistGeneratorHandler(HashMap<String, int[]> genresStored) {
        this.subscribedPodcasts = new ArrayList<>();
        this.genresStored = genresStored;
        this.sortedFeeds = new ArrayList<>();
    }

    //Need to call this after constructor. Was removed to facilitate testing
    public void setSubscriptionInformation(){
        this.subscriptions = DBReader.getNavDrawerData();
        subscribedPodcasts.addAll(subscriptions.feeds);
    }

    public List<Feed> setSortedFeeds(List<Integer> genreCodes){
        for (Feed feed : subscribedPodcasts) {
            if(genresStored.containsKey(feed.getTitle())){
                int[] genres = genresStored.get(feed.getTitle());
                if(containsGenreCode(genres, genreCodes)){
                    sortedFeeds.add(feed);
                }
            }
        }
        return sortedFeeds;
    }

    private boolean containsGenreCode(int[] genres, List<Integer> genreCodes){
        for (int code : genres){
            if(genreCodes.contains(code)){
                return true;
            }
        }
        return false;
    }

    public void clearFeeds(){
        sortedFeeds = new ArrayList<>();
    }

    //Methods for unit testing purposes
    public void setSubscribedFeedsForTestingOnly(List<Feed> listOfMockFeeds){
        subscribedPodcasts = listOfMockFeeds;
    }


}
