package de.danoeh.antennapod.core.playlist;

import java.io.Serializable;
import java.util.ArrayList;

import de.danoeh.antennapod.core.feed.FeedItem;

public class Playlist implements Serializable{

    private static final long serialVersionUID = 1L;
    private String name;
    private ArrayList<Long> feedItemsIds;

    public Playlist(String name){
        this.name = name;
        this.feedItemsIds = new ArrayList<Long>();
    }

    public String getName() {
        return name;
    }

    public ArrayList<Long> getPodcasts() {
        return feedItemsIds;
    }

    public int getNumOfPodcasts() {
        return feedItemsIds.size();
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPodcasts(ArrayList<Long> feedItemsIds){
        this.feedItemsIds = feedItemsIds;
    }

    public boolean addPodcast(FeedItem feedItem){
        if (this.feedItemsIds.contains(feedItem.getId())) {
            return false;
        } else {
            this.feedItemsIds.add(feedItem.getId());
            return true;
        }
    }

    public void removePodcast(Long id){
        this.feedItemsIds.remove(id);
    }

    @Override
    public String toString() {
        return "Playlist{" +
                "name='" + name + '\'' +
                ", numOfPodcasts=" + getNumOfPodcasts() +
                ", feedItemIds=" + feedItemsIds +
                '}';
    }

}
