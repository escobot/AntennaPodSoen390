package de.danoeh.antennapod.core.util;

import java.util.List;
import java.util.Map;

import de.danoeh.antennapod.core.service.download.DownloadStatus;

public class DownloadStatusUtil {

    public static long[] getIds(List<DownloadStatus> items) {
        Map<String, Integer> lookupMap = FeedItemLookupMap.getInstance();
        if(items == null || items.size() == 0) {
            return new long[0];
        }
        long[] result = new long[items.size()];
        for(int i=0; i < items.size(); i++) {
            if(lookupMap.containsKey(items.get(i).getTitle())) {
                result[i] = new Long(lookupMap.get(items.get(i).getTitle()));
            }
        }
        return result;
    }
}
