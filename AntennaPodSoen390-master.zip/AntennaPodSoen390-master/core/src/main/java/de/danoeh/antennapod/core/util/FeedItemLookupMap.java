package de.danoeh.antennapod.core.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.storage.DBReader;

/**
 * Helper class for converting a list DownloadStatus objects to FeedItem objects
 * Uses same idea as the singleton pattern to keep one instance of the lookupMap
 */
public class FeedItemLookupMap {

    private static Map<String, Integer> lookUpMap;

    private FeedItemLookupMap() {
    }

    /**
     * One cannot access the FeedItem ids from a DownloadStatus object. However, the
     * both FeedItem and DownloadStatus have the same titles.
     * @return a map object containing feed titles as keys and feed ids as values
     */
    public static Map<String, Integer> getInstance() {
        List<FeedItem> downloadedItems = DBReader.getDownloadedItems();
        if (lookUpMap == null) {
            lookUpMap = new HashMap<>();
            downloadedItems.forEach(item -> {
                if (item.hasMedia()) {
                    lookUpMap.put(item.getTitle(), (int) item.getId());
                }
            });
        } else {
            downloadedItems.forEach(item -> {
                if (item.hasMedia() && !lookUpMap.containsKey(item.getTitle())) {
                    lookUpMap.put(item.getTitle(), (int) item.getId());
                }
            });
        }
        return lookUpMap;
    }
}
