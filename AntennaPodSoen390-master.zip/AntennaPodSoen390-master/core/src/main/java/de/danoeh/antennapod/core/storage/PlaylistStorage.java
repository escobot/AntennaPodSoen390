package de.danoeh.antennapod.core.storage;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.playlist.Playlist;

public class PlaylistStorage {

    final static String FILENAME = "playlistStorage";
    static File saveFile;

    public static void savePlaylists(ArrayList<Playlist> playlists, Context context){
       if(saveFile != null) {
           if (!saveFile.exists()) {
               saveFile = new File(context.getFilesDir(), FILENAME);
           }
       }
       try{
           FileOutputStream fos = new FileOutputStream(saveFile);
           ObjectOutputStream oos = new ObjectOutputStream(fos);
           oos.writeObject(playlists);
           System.out.println("Saved playlists successfully");
           oos.close();
       } catch (Exception e){
           e.printStackTrace();
       }

    }

    public static ArrayList<Playlist> loadPlaylists(Context context){
        ArrayList<Playlist> result = null;
        saveFile = new File(context.getFilesDir(),FILENAME);
        if(!saveFile.exists()){
            result = new ArrayList<Playlist>();
            System.out.println("Savefile doesn't exist, creating new arraylist<playlist>");
        }else {
            try{
                FileInputStream fis = new FileInputStream(saveFile);
                ObjectInputStream ois = new ObjectInputStream(fis);
                result = (ArrayList<Playlist>) ois.readObject();
                if(result == null){
                    System.out.println("Savefile contains null arraylist. Initializing arraylist");
                    result = new ArrayList<Playlist>();
                }
                System.out.println("Storage loaded playlists successfully\nSize: " + result.size());
                ois.close();
                return result;
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return result;
    }

    public static boolean wipePlaylistSaveFile(Context context){
        boolean deleted = false;
        if(saveFile == null){
            saveFile = new File(context.getFilesDir(), FILENAME);
        }
        try{
            deleted = saveFile.delete();
            return deleted;
        }catch(Exception e){
            e.printStackTrace();
        }
        return deleted;
    }

    public static ArrayList<FeedItem> getFeedItemsFromIds(ArrayList<Long> feedItemsIds){
        ArrayList<FeedItem> result = new ArrayList<>();
        for(Long id : feedItemsIds){
            try {
                result.add(DBReader.getFeedItem(id));
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
        return result;
    }
}
