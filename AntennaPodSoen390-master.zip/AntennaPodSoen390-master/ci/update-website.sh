#!/bin/bash

set -e
echo "Starting to upload static analysis reports\n"
cp -R app/build/outputs/reports $HOME/$TRAVIS_BUILD_NUMBER
cp app/build/reports/lint-results.html $HOME/$TRAVIS_BUILD_NUMBER
cd $HOME
git config --global user.email "travis@travis-ci.org"
git config --global user.name "Travis CI"
git clone --quiet https://${GH_TOKEN}@github.com/pbgnz/pbgnz.github.io.git master > /dev/null
cd master
cp -Rf $HOME/$TRAVIS_BUILD_NUMBER .
git add -f .
git commit -m "Travis build $TRAVIS_BUILD_NUMBER"
git push -fq origin master > /dev/null
echo "Done uploading static analysis\n"