package de.danoeh.antennapod.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.core.playlist.Playlist;

/**
 * Created by Emanuel on 2018-02-11.
 */

public class AddToPlaylistAdapter extends RecyclerView.Adapter<AddToPlaylistAdapter.AddToPlaylistViewHolder>{

    ArrayList<Playlist> playlistList;
    private OnItemClickListener mListener;

    public AddToPlaylistAdapter(ArrayList<Playlist> playlists){
        this.playlistList = playlists;
    }

    public interface OnItemClickListener{
        void onItemClick(int position);
    }

    public void setOnClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public AddToPlaylistAdapter(ArrayList<Playlist> playlistsList, Context context){
        this.playlistList = playlistsList;
    }

    @Override
    public AddToPlaylistViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.playlist_listitem, parent, false);
        AddToPlaylistViewHolder viewHolder = new AddToPlaylistViewHolder(v, mListener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(AddToPlaylistViewHolder holder, int position){
        holder.text.setText(playlistList.get(position).getName());
    }

    @Override
    public int getItemCount(){
        return playlistList.size();
    }

    public static class AddToPlaylistViewHolder extends RecyclerView.ViewHolder{

        protected TextView text;

        public AddToPlaylistViewHolder(View itemView, final AddToPlaylistAdapter.OnItemClickListener listener){
            super(itemView);
            text = (TextView) itemView.findViewById(R.id.text_id);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
