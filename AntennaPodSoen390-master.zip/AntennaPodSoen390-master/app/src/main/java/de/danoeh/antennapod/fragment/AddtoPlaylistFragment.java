package de.danoeh.antennapod.fragment;


import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.adapter.AddToPlaylistAdapter;
import de.danoeh.antennapod.adapter.PlaylistsRecyclerAdapter;
import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.playlist.Playlist;
import de.danoeh.antennapod.core.storage.PlaylistStorage;

public class AddtoPlaylistFragment extends DialogFragment {

    public static final String TAG = "AddtoPlaylistFragment";

    private RecyclerView recyclerView;
    private AddToPlaylistAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<Playlist> playlistList = new ArrayList<Playlist>();
    private FeedItem podcast;

    public static AddtoPlaylistFragment newInstance(){
        return new AddtoPlaylistFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceStats){
        super.onCreate((savedInstanceStats));

        //Loads the playlists from storage or initiates them
        if(playlistList.isEmpty()){
            playlistList = PlaylistStorage.loadPlaylists(getContext());
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceStats){
        View root = inflater.inflate(R.layout.add_to_playlist_fragment, container, false);

        recyclerView = (RecyclerView) root.findViewById(R.id.recycler_view_playlist);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        adapter = new AddToPlaylistAdapter(playlistList, getActivity().getApplicationContext());
        recyclerView.setAdapter(adapter);

        adapter.setOnClickListener(new AddToPlaylistAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                if(playlistList.get(position).addPodcast(podcast)){
                    PlaylistStorage.savePlaylists(playlistList, getContext());
                    Toast.makeText(getActivity(), "Added to Playlist " + playlistList.get(position).getName(), Toast.LENGTH_LONG).show();
                    //Close fragment
                    dismiss();
                }
                else{
                    Toast.makeText(getActivity(), podcast.getTitle() + " already exists in playlist " + playlistList.get(position).getName(), Toast.LENGTH_LONG).show();
                    //Close fragment
                    dismiss();
                }

            }
        });

        return root;
    }

    public void selectedPodcast(FeedItem feed){
        podcast = feed;
    }
}
