package de.danoeh.antennapod.fragment;

import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.adapter.PlaylistsRecyclerAdapter;
import de.danoeh.antennapod.core.playlist.Playlist;
import de.danoeh.antennapod.core.storage.PlaylistStorage;

public class PlaylistsFragment extends Fragment{

    public static final String TAG = "PlaylistsFragment";

    private RecyclerView recyclerView;
    private PlaylistsRecyclerAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<Playlist> playlistList = new ArrayList<Playlist>();
    private LayoutInflater layoutInflater;

    public static PlaylistsFragment newInstance(){
        return new PlaylistsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceStats){
        super.onCreate(savedInstanceStats);
        setHasOptionsMenu(true);
        //Loads the playlists from storage or initiates them
        if(playlistList.isEmpty()){
            playlistList = PlaylistStorage.loadPlaylists(getContext());
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View root = inflater.inflate(R.layout.playlists_fragment, container, false);
        ((MainActivity) getActivity()).getSupportActionBar().setTitle(R.string.playlists_label);
        layoutInflater = inflater;


        recyclerView = (RecyclerView) root.findViewById(R.id.recycler_view_playlist);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        adapter = new PlaylistsRecyclerAdapter(playlistList, getActivity().getApplicationContext());
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new PlaylistsRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Fragment fragment = new PlaylistFragment();
                Bundle args = new Bundle();

                args.putSerializable("playlist",playlistList.get(position));

                fragment.setArguments(args);

                android.support.v4.app.FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(((ViewGroup)getView().getParent()).getId(), fragment);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();

            }
        });

        adapter.setOnLongItemClickListener(new PlaylistsRecyclerAdapter.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(int position) {
                AlertDialog.Builder playlistOptions = new AlertDialog.Builder(getActivity());
                playlistOptions.setTitle(playlistList.get(position).getName());
                playlistOptions.setItems(R.array.playlist_options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String temp[] = getResources().getStringArray(R.array.playlist_options);
                        if(temp[which].equals("Delete Playlist")){
                            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setMessage("Delete Playlist " + playlistList.get(position).getName() + "?")
                                    .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            playlistList = deletePlaylist(playlistList, position);
                                            PlaylistStorage.savePlaylists(playlistList, getContext());
                                            adapter.notifyDataSetChanged();
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            //do nothing
                                        }
                                    });

                            AlertDialog deleteDialog = builder.create();
                            deleteDialog.show();
                        }
                    }
                });


                playlistOptions.show();
                return false;
            }
        });
        FloatingActionButton addPlaylistButton = (FloatingActionButton) root.findViewById(R.id.createPlaylistButton);
        addPlaylistButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
                View createPlaylistDialog = inflater.inflate(R.layout.create_playlist_dialog,null);
                Button cancelBtn = (Button) createPlaylistDialog.findViewById(R.id.cancelBtn);
                cancelBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                Button createBtn = (Button) createPlaylistDialog.findViewById(R.id.createBtn);
                EditText newPlaylistName = (EditText) createPlaylistDialog.findViewById(R.id.newPlaylistName);
                createBtn.setOnClickListener(view -> {
                    boolean exists = false;
                    for(Playlist p : playlistList){
                        if(p.getName().equals(newPlaylistName.getText().toString())){
                            alertDialog.dismiss();
                            Toast.makeText(getActivity(), newPlaylistName.getText() + " already exists the playlist was not created successfully", Toast.LENGTH_LONG).show();
                            exists = true;
                        }
                    }
                    if(!exists){
                        System.out.println("Playlist \"" + newPlaylistName.getText()+ "\" created");
                        playlistList.add(new Playlist(newPlaylistName.getText().toString()));
                        //Save playlist to storage.
                        PlaylistStorage.savePlaylists(playlistList,getContext());
                        //dismiss dialog at the end
                        alertDialog.dismiss();
                        Toast.makeText(getActivity(), newPlaylistName.getText() + " was created", Toast.LENGTH_LONG).show();

                    }
                });

                alertDialog.setView(createPlaylistDialog);
                alertDialog.show();
            }
        });
        return root;
    }

    public ArrayList<Playlist> deletePlaylist(ArrayList<Playlist> list, int position){
        list.remove(list.get(position));

        return list;
    }


    public void onDestroyView(){
        super.onDestroyView();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if(!isAdded()) {
            return;
        }
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.playlists_context, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem){
        if(!super.onOptionsItemSelected(menuItem)) {
            switch (menuItem.getItemId()) {
                case R.id.auto_generate:
                    AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
                    View createPlaylistDialog = layoutInflater.inflate(R.layout.create_playlist_dialog,null);
                    alertDialog.setView(createPlaylistDialog);
                    alertDialog.show();

                    Button cancelBtn = (Button) createPlaylistDialog.findViewById(R.id.cancelBtn);
                    cancelBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            alertDialog.dismiss();
                        }
                    });

                    Button createBtn = (Button) createPlaylistDialog.findViewById(R.id.createBtn);
                    EditText newPlaylistName = (EditText) createPlaylistDialog.findViewById(R.id.newPlaylistName);
                    createBtn.setOnClickListener(view -> {
                        boolean exists = false;
                        for(Playlist p : playlistList){
                            if(p.getName().equals(newPlaylistName.getText().toString())){
                                alertDialog.dismiss();
                                Toast.makeText(getActivity(), newPlaylistName.getText() + " already exists the playlist was not created successfully", Toast.LENGTH_LONG).show();
                                exists = true;
                            }
                        }
                        if(!exists){
                            Playlist newPlaylist = new Playlist(newPlaylistName.getText().toString());
                            playlistList.add(newPlaylist);
                            PlaylistStorage.savePlaylists(playlistList, getContext());

                            Bundle args = new Bundle();
                            args.putString("playlist name", newPlaylistName.getText().toString());
                            PlaylistCategoriesFragment playlistCategoriesFragment = new PlaylistCategoriesFragment();
                            playlistCategoriesFragment.setArguments(args, newPlaylist);

                            ((MainActivity) getActivity()).loadChildFragment(playlistCategoriesFragment);
                            alertDialog.dismiss();
                        }
                    });
                    return true;
                default:
                    return false;
            }
        }
        else {
            return true;
        }
    }

}
