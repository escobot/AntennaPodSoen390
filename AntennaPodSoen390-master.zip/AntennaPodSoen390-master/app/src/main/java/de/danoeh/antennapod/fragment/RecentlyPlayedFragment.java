package de.danoeh.antennapod.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.adapter.RecentlyPlayedAdapter;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.storage.DBReader;
import de.danoeh.antennapod.core.util.FeedItemUtil;
import de.danoeh.antennapod.core.util.comparator.FeedItemLastPlayedComparator;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * RecentlyPlayedFragment
 * Displays all recently played podcast episodes
 */
public class RecentlyPlayedFragment extends ListFragment {

    private static final String TAG = RecentlyPlayedFragment.class.getSimpleName();

    private static final int RECENTLY_PLAYED_LIMIT = 25;

    private List<FeedItem> items;
    private RecentlyPlayedAdapter listAdapter;

    private boolean viewCreated = false;

    private Subscription subscription;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadItems();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        if(subscription != null) {
            subscription.unsubscribe();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        if(subscription != null) {
            subscription.unsubscribe();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        listAdapter = null;
        viewCreated = false;
        if(subscription != null) {
            subscription.unsubscribe();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (viewCreated && items != null) {
            onFragmentLoaded();
        }
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // add padding
        final ListView lv = getListView();
        lv.setClipToPadding(false);
        final int vertPadding = getResources().getDimensionPixelSize(R.dimen.list_vertical_padding);
        lv.setPadding(0, vertPadding, 0, vertPadding);

        viewCreated = true;
        if (items != null && getActivity() != null) {
            onFragmentLoaded();
        }

        setEmptyText(getString(R.string.recently_played_empty));
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        position -= l.getHeaderViewsCount();
        long[] ids = FeedItemUtil.getIds(items);
        ((MainActivity) getActivity()).loadChildFragment(ItemFragment.newInstance(ids, position));
    }

    private void onFragmentLoaded() {
        if (listAdapter == null) {
            listAdapter = new RecentlyPlayedAdapter(getActivity(), itemAccess);
            setListAdapter(listAdapter);
        }
        setListShown(true);
        listAdapter.notifyDataSetChanged();
        getActivity().supportInvalidateOptionsMenu();
    }

    private RecentlyPlayedAdapter.ItemAccess itemAccess = new RecentlyPlayedAdapter.ItemAccess() {
        @Override
        public int getCount() {
            return (items != null) ? items.size() : 0;
        }

        @Override
        public FeedItem getItem(int position) {
            if (items != null && 0 <= position && position < items.size()) {
                return items.get(position);
            } else {
                return null;
            }
        }
    };

    private void loadItems() {
        if(subscription != null) {
            subscription.unsubscribe();
        }
        if (items == null && viewCreated) {
            setListShown(false);
        }
        subscription = Observable.fromCallable(this::loadData)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(result -> {
                    if (result != null) {
                        items = result;
                        if (viewCreated && getActivity() != null) {
                            onFragmentLoaded();
                        }
                    }
                }, error ->  Log.e(TAG, Log.getStackTraceString(error)));
    }

    protected List<FeedItem> loadData() {
        List<FeedItem> items = DBReader.getRecentlyPlayedEpisodes(RECENTLY_PLAYED_LIMIT);
        for (Iterator<FeedItem> itr = items.listIterator(); itr.hasNext(); ) {
            // remove the feed items that have a default last played date
            if (itr.next().getLastPlayed().getYear() < 118) {
                itr.remove();
            }
        }
        Collections.sort(items, new FeedItemLastPlayedComparator());
        return items;
    }
}
