package de.danoeh.antennapod.service;

import de.danoeh.antennapod.core.util.Converter;

public class PodcastTimeService {

    public static String calculatePodcastDuration(String playbackSpeed, int duration) {
        double playbackSpeedDouble = Double.parseDouble(playbackSpeed);

        double newDuration =  (double) duration / playbackSpeedDouble;

        return Converter.getDurationStringLong((int) newDuration);
    }

    public static long calculateAverageEpisodeLength(long totalDuration, long numOfEpisodes) {
        if (numOfEpisodes == 0)
            return 0;
        else
            return totalDuration/numOfEpisodes;
    }

}
