package de.danoeh.antennapod.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.adapter.itunes.ItunesCategoriesAdapter;
import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.playlist.Playlist;
import de.danoeh.antennapod.core.playlist.PlaylistGeneratorHandler;
import de.danoeh.antennapod.core.storage.DBReader;
import de.danoeh.antennapod.core.storage.GenreStorage;
import de.danoeh.antennapod.core.storage.PlaylistStorage;

public class PlaylistCategoriesFragment extends Fragment{

    public static final String TAG = "PlaylistCategoriesFragment";

    private ItunesCategoriesAdapter adapter;
    private GridView gridView;
    private List<String> categories;
    private String header = "Select Genre for Playlist:";
    private HashMap<String, int[]> genres = new HashMap<>();
    private PlaylistGeneratorHandler playlistGeneratorHandler;
    private List<Feed> subscribedFeeds;
    private String playlistName;
    private ArrayList<Playlist> playlistList;
    private Playlist playlist;

    @Override
    public void onCreate(Bundle savedInstanceStats){
        super.onCreate(savedInstanceStats);

        String[] categoriesArray = getResources().getStringArray(R.array.itunes_categories);
        categories = Arrays.asList(categoriesArray);
        genres = GenreStorage.loadGenres(getContext());
        playlistGeneratorHandler = new PlaylistGeneratorHandler(genres);
        playlistGeneratorHandler.setSubscriptionInformation();
        playlistList = PlaylistStorage.loadPlaylists(getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceStats){
        View root = inflater.inflate(R.layout.itunes_categories, container, false);
        gridView = (GridView) root.findViewById(R.id.gridView);
        adapter = new ItunesCategoriesAdapter(categories);
        gridView.setAdapter(adapter);
        if(((MainActivity) getActivity()).getSupportActionBar() != null) {
            ((MainActivity) getActivity()).getSupportActionBar().setTitle(header);
        }

        genres = GenreStorage.loadGenres(getContext());

        gridView.setOnItemClickListener((parent, view, position, id) -> generatePlaylistFromQuery(position));
        return root;
    }

    public void generatePlaylistFromQuery(int position){
        Log.d("Category clicked:", categories.get(position));

        int[] categoryCodes = getCategoryCodesFromQuery(categories.get(position));
        playlistGeneratorHandler.clearFeeds();
        List<Integer> codes = new ArrayList<>();
        for(int code : categoryCodes){
            codes.add(code);
            Log.d("Code", "" + code);
        }
        subscribedFeeds =  playlistGeneratorHandler.setSortedFeeds(codes);
        if(subscribedFeeds.size() > 0){
            for (Feed feed : subscribedFeeds){
                Log.d("Feed Title:", "" + feed.getTitle());
                List<FeedItem> feedItems = fetchFeedItemsFromDB(feed);
                for(int i = 0; i < 3; i++){
                    playlist.addPodcast(feedItems.get(i));
                }
            }
            displayErrorMessage("Added " + categories.get(position) + " feed items");
        }
        else {
            displayErrorMessage("No podcasts found under the category: " + categories.get(position) );
        }
    }

    public int[] getCategoryCodesFromQuery(String category){
        switch (category){
            case "Arts":
                return getResources().getIntArray(R.array.art_codes);
            case "Business":
                return getResources().getIntArray(R.array.business_codes);
            case "Comedy":
                return getResources().getIntArray(R.array.comedy_codes);
            case "Medicine":
                return getResources().getIntArray(R.array.medicine_codes);
            case "Science":
                return getResources().getIntArray(R.array.science_codes);
            case "Sports":
                return getResources().getIntArray(R.array.sports_codes);
            case "Technology":
                return getResources().getIntArray(R.array.technology_codes);
            case "Food":
                return getResources().getIntArray(R.array.food_codes);
            case "Music":
                return getResources().getIntArray(R.array.music_codes);
            default:
                return new int[0];
        }
    }

    public void setArguments(Bundle arguments, Playlist playlist){
        playlistName = arguments.getString("playlist name");
        this.playlist = playlist;
    }

    public boolean playlistIsEmpty(){
      return playlist.getNumOfPodcasts() == 0;
    }

    @Override
    public void onDestroyView(){
        super.onDestroyView();
        Playlist playlistToBeRemoved = null;
        for(Playlist p : playlistList){
            if(p.getName().equals(playlistName)){
                playlistToBeRemoved = p;
            }
        }
        if(playlistToBeRemoved != null){
            playlistList.remove(playlistToBeRemoved);
        }
        playlistList.add(playlist);
        PlaylistStorage.savePlaylists(playlistList, getContext());
        if(playlistIsEmpty()){
            Toast.makeText(getActivity(), "Created empty playlist: " + playlistName, Toast.LENGTH_LONG).show();
        }
        else
            Toast.makeText(getActivity(), "Playlist " + playlistName + " created successfully", Toast.LENGTH_LONG).show();
    }

    public void displayErrorMessage(String errorMessage){
        Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
    }

    public List<FeedItem> fetchFeedItemsFromDB(Feed feed){
        return DBReader.getFeedItemList(feed);
    }

    public void setItemsForTestingOnly(List<String> categories, PlaylistGeneratorHandler mockHandler, Playlist mockPlaylist ){
        this.categories = categories;
        this.playlistGeneratorHandler = mockHandler;
        this.playlist = mockPlaylist;
    }
}
