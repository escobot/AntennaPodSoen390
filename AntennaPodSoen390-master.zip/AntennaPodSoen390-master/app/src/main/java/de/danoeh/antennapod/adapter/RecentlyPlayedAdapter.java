package de.danoeh.antennapod.adapter;

import android.content.Context;
import android.os.Build;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.glide.ApGlideSettings;
import de.danoeh.antennapod.core.util.DateUtils;

/**
 * RecentlyPlayedAdapter
 * Shows a list of recently played podcast episodes
 */
public class RecentlyPlayedAdapter extends BaseAdapter {

    private final Context context;
    private final ItemAccess itemAccess;

    public RecentlyPlayedAdapter(Context context, ItemAccess itemAccess) {
        this.context = context;
        this.itemAccess = itemAccess;
    }

    @Override
    public int getCount() {
        return itemAccess.getCount();
    }

    @Override
    public FeedItem getItem(int position) {
        return itemAccess.getItem(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        final FeedItem item = getItem(position);
        if (item == null) return null;

        if (convertView == null) {
            holder = new Holder();
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.recentlyplayed_item,
                    parent, false);
            holder.imageView = (ImageView) convertView.findViewById(R.id.imgvImage);
            holder.title = (TextView) convertView.findViewById(R.id.txtvTitle);
            if(Build.VERSION.SDK_INT >= 23) {
                holder.title.setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_FULL);
            }
            holder.lastPlayed = (TextView) convertView
                    .findViewById(R.id.txtvLastPlayedDate);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        Glide.with(context)
                .load(item.getImageLocation())
                .placeholder(R.color.light_gray)
                .error(R.color.light_gray)
                .diskCacheStrategy(ApGlideSettings.AP_DISK_CACHE_STRATEGY)
                .fitCenter()
                .dontAnimate()
                .into(holder.imageView);

        holder.title.setText(item.getTitle());
        String lastPlayedStr = DateUtils.formatAbbrev(context, item.getLastPlayed());
        holder.lastPlayed.setText("Last played: " + lastPlayedStr);

        return convertView;
    }

    static class Holder {
        ImageView imageView;
        TextView title;
        TextView lastPlayed;
    }

    public interface ItemAccess {
        int getCount();
        FeedItem getItem(int position);
    }
}
