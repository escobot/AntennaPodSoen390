package de.danoeh.antennapod.adapter;

import android.content.Context;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.joanzapata.iconify.Iconify;
import com.nineoldandroids.view.ViewHelper;

import org.jetbrains.annotations.Nullable;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.feed.FeedMedia;
import de.danoeh.antennapod.core.glide.ApGlideSettings;
import de.danoeh.antennapod.core.preferences.UserPreferences;
import de.danoeh.antennapod.core.storage.DownloadRequester;
import de.danoeh.antennapod.core.util.Converter;
import de.danoeh.antennapod.core.util.DateUtils;
import de.danoeh.antennapod.core.util.LongList;
import de.danoeh.antennapod.core.util.NetworkUtils;

public class PlaylistRecyclerAdapter extends RecyclerView.Adapter<PlaylistRecyclerAdapter.PlaylistViewHolder> {
    private ArrayList<FeedItem> feedItemList;
    private OnItemClickListener mListener;
    private OnItemLongClickListener longListener;
    private Context context;
    private static String TAG = "PlaylistRecyclerAdapter";

    private FeedItem selectedItem;

    private WeakReference<MainActivity> mainActivity;
    private final ItemAccess itemAccess;
    private final ActionButtonCallback actionButtonCallback;
    private final ActionButtonUtils actionButtonUtils;
    private final ItemTouchHelper itemTouchHelper;

    private static int playingBackGroundColor;
    private static int normalBackGroundColor;

    public PlaylistRecyclerAdapter(ArrayList<FeedItem> feedItemList, Context context, MainActivity mainActivity, ItemAccess itemAccess, ActionButtonCallback actionButtonCallback,
                                   ItemTouchHelper itemTouchHelper){
        this.mainActivity = new WeakReference<>(mainActivity);
        this.itemAccess = itemAccess;
        this.actionButtonUtils = new ActionButtonUtils(mainActivity);
        this.actionButtonCallback = actionButtonCallback;
        this.itemTouchHelper = itemTouchHelper;

        this.feedItemList = feedItemList;
        this.context = context;

        if(UserPreferences.getTheme() == R.style.Theme_AntennaPod_Dark) {
            playingBackGroundColor = ContextCompat.getColor(context, R.color.highlight_dark);
        } else {
            playingBackGroundColor = ContextCompat.getColor(context, R.color.highlight_light);
        }
        normalBackGroundColor = ContextCompat.getColor(context, android.R.color.transparent);
    }

    public FeedItem getSelectedItem(int position) {
        return feedItemList.get(position);
    }

    public interface OnItemClickListener{
        void onItemClick(int position);
    }

    public interface OnItemLongClickListener{
        boolean onItemLongClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public void setOnLongItemClickListener(OnItemLongClickListener listener){
        longListener = listener;
    }

    @Override
    public PlaylistViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.queue_listitem, parent, false);
        return new PlaylistViewHolder(v, mListener, longListener);
    }

    @Override
    public void onBindViewHolder(PlaylistViewHolder holder, int position){
        FeedItem item = feedItemList.get(position);
        holder.bind(item);
    }


    @Override
    public long getItemId(int position) {
        FeedItem item = itemAccess.getItem(position);
        return item != null ? item.getId() : RecyclerView.NO_POSITION;
    }

    private static int countMatches(final CharSequence str, final char ch) {
        if (TextUtils.isEmpty(str)) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (ch == str.charAt(i)) {
                count++;
            }
        }
        return count;
    }

    @Override
    public int getItemCount(){
        if(feedItemList == null){
            return 0;
        }
        else {
            return feedItemList.size();
        }
    }

    public class PlaylistViewHolder extends RecyclerView.ViewHolder implements ItemTouchHelperViewHolderPlaylists{
        private FrameLayout container;
        private ImageView dragHandle;
        private TextView placeholder;
        private ImageView cover;
        private TextView title;
        private TextView pubDate;
        private TextView progressLeft;
        private TextView progressRight;
        private ProgressBar progressBar;
        private ImageButton butSecondary;

        private FeedItem item;

        public PlaylistViewHolder(View itemView, final OnItemClickListener listener, final OnItemLongClickListener longListener){
            super(itemView);
            container = (FrameLayout) itemView.findViewById(R.id.container);
            dragHandle = (ImageView) itemView.findViewById(R.id.drag_handle);
            placeholder = (TextView) itemView.findViewById(R.id.txtvPlaceholder);
            cover = (ImageView) itemView.findViewById(R.id.imgvCover);
            title = (TextView) itemView.findViewById(R.id.txtvTitle);
            if(Build.VERSION.SDK_INT >= 23) {
                title.setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_FULL);
            }
            pubDate = (TextView) itemView.findViewById(R.id.txtvPubDate);
            progressLeft = (TextView) itemView.findViewById(R.id.txtvProgressLeft);
            progressRight = (TextView) itemView.findViewById(R.id.txtvProgressRight);
            butSecondary = (ImageButton) itemView.findViewById(R.id.butSecondaryAction);
            progressBar = (ProgressBar) itemView.findViewById(R.id.progressBar);
            dragHandle.setOnTouchListener((v1, event) -> {
                if (MotionEventCompat.getActionMasked(event) == MotionEvent.ACTION_DOWN) {
                    Log.d(TAG, "startDrag()");
                   itemTouchHelper.startDrag(PlaylistViewHolder.this);
                }
                return false;
            });


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            listener.onItemClick(position);
                        }
                    }
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener(){
                @Override
                public boolean onLongClick(View v){
                    longListener.onItemLongClick(getAdapterPosition());
                    return true;
                }
            });
        }

        public void bind(FeedItem item) {

            dragHandle.setVisibility(View.VISIBLE);

            placeholder.setText(item.getFeed().getTitle());

            title.setText(item.getTitle());
            FeedMedia media = item.getMedia();

            title.setText(item.getTitle());
            String pubDateStr = DateUtils.formatAbbrev(mainActivity.get(), item.getPubDate());
            int index = 0;
            if(countMatches(pubDateStr, ' ') == 1 || countMatches(pubDateStr, ' ') == 2) {
                index = pubDateStr.lastIndexOf(' ');
            } else if(countMatches(pubDateStr, '.') == 2) {
                index = pubDateStr.lastIndexOf('.');
            } else if(countMatches(pubDateStr, '-') == 2) {
                index = pubDateStr.lastIndexOf('-');
            } else if(countMatches(pubDateStr, '/') == 2) {
                index = pubDateStr.lastIndexOf('/');
            }
            if(index > 0) {
                pubDateStr = pubDateStr.substring(0, index+1).trim() + "\n" + pubDateStr.substring(index+1);
            }
            pubDate.setText(pubDateStr);

            if (media != null) {
                final boolean isDownloadingMedia = DownloadRequester.getInstance().isDownloadingFile(media);
                FeedItem.State state = item.getState();
                if (isDownloadingMedia) {
                    progressLeft.setText(Converter.byteToString(itemAccess.getItemDownloadedBytes(item)));
                    if(itemAccess.getItemDownloadSize(item) > 0) {
                        progressRight.setText(Converter.byteToString(itemAccess.getItemDownloadSize(item)));
                    } else {
                        progressRight.setText(Converter.byteToString(media.getSize()));
                    }
                    progressBar.setProgress(itemAccess.getItemDownloadProgressPercent(item));
                    progressBar.setVisibility(View.VISIBLE);
                } else if (state == FeedItem.State.PLAYING
                        || state == FeedItem.State.IN_PROGRESS) {
                    if (media.getDuration() > 0) {
                        int progress = (int) (100.0 * media.getPosition() / media.getDuration());
                        progressBar.setProgress(progress);
                        progressBar.setVisibility(View.VISIBLE);
                        progressLeft.setText(Converter
                                .getDurationStringLong(media.getPosition()));
                        progressRight.setText(Converter.getDurationStringLong(media.getDuration()));
                    }
                } else {
                    if(media.getSize() > 0) {
                        progressLeft.setText(Converter.byteToString(media.getSize()));
                    } else if(NetworkUtils.isDownloadAllowed() && !media.checkedOnSizeButUnknown()) {
                        progressLeft.setText("{fa-spinner}");
                        Iconify.addIcons(progressLeft);
                        NetworkUtils.getFeedMediaSizeObservable(media)
                                .subscribe(
                                        size -> {
                                            if (size > 0) {
                                                progressLeft.setText(Converter.byteToString(size));
                                            } else {
                                                progressLeft.setText("");
                                            }
                                        }, error -> {
                                            progressLeft.setText("");
                                            Log.e(TAG, Log.getStackTraceString(error));
                                        });
                    } else {
                        progressLeft.setText("");
                    }
                    progressRight.setText(Converter.getDurationStringLong(media.getDuration()));
                    progressBar.setVisibility(View.GONE);
                }

                if(media.isCurrentlyPlaying()) {
                    container.setBackgroundColor(playingBackGroundColor);
                } else {
                    container.setBackgroundColor(normalBackGroundColor);
                }
            }

            actionButtonUtils.configureActionButton(butSecondary, item, true);
            butSecondary.setFocusable(false);
            butSecondary.setTag(item);
            butSecondary.setOnClickListener(secondaryActionListener);

            Glide.with(mainActivity.get())
                    .load(item.getImageLocation())
                    .diskCacheStrategy(ApGlideSettings.AP_DISK_CACHE_STRATEGY)
                    .fitCenter()
                    .dontAnimate()
                    .into(new CoverTarget(item.getFeed().getImageLocation(), placeholder, cover, mainActivity.get()));
        }

        @Override
        public void onItemSelected() {
            ViewHelper.setAlpha(itemView, 0.5f);
        }

        @Override
        public void onItemClear() {
            ViewHelper.setAlpha(itemView, 1.0f);
        }
    }
    private View.OnClickListener secondaryActionListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            FeedItem item = (FeedItem) v.getTag();
            actionButtonCallback.onActionButtonPressed(item, itemAccess.getQueueIds());
        }
    };
    public interface ItemAccess {
        FeedItem getItem(int position);
        int getCount();
        long getItemDownloadedBytes(FeedItem item);
        long getItemDownloadSize(FeedItem item);
        int getItemDownloadProgressPercent(FeedItem item);
        LongList getQueueIds();
    }

    public interface ItemTouchHelperViewHolderPlaylists {

        void onItemSelected();

        void onItemClear();
    }
}
