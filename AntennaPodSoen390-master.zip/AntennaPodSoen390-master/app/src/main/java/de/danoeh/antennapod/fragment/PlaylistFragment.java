package de.danoeh.antennapod.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.adapter.DefaultActionButtonCallback;
import de.danoeh.antennapod.adapter.PlaylistRecyclerAdapter;
import de.danoeh.antennapod.core.dialog.DownloadRequestErrorDialogCreator;
import de.danoeh.antennapod.core.event.DownloadEvent;
import de.danoeh.antennapod.core.event.DownloaderUpdate;
import de.danoeh.antennapod.core.event.FeedItemEvent;
import de.danoeh.antennapod.core.feed.EventDistributor;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.feed.FeedMedia;
import de.danoeh.antennapod.core.playlist.Playlist;
import de.danoeh.antennapod.core.service.download.DownloadService;
import de.danoeh.antennapod.core.service.download.Downloader;
import de.danoeh.antennapod.core.storage.DBTasks;
import de.danoeh.antennapod.core.storage.DBWriter;
import de.danoeh.antennapod.core.storage.DownloadRequestException;
import de.danoeh.antennapod.core.storage.DownloadRequester;
import de.danoeh.antennapod.core.storage.GenreStorage;
import de.danoeh.antennapod.core.storage.PlaylistStorage;
import de.danoeh.antennapod.core.util.FeedItemUtil;
import de.danoeh.antennapod.core.util.LongList;
import de.danoeh.antennapod.menuhandler.MenuItemUtils;
import de.greenrobot.event.EventBus;

import static org.apache.commons.lang3.ArrayUtils.shuffle;

public class PlaylistFragment extends Fragment{

    public static final String TAG = "PlaylistFragment";

    private static final int EVENTS = EventDistributor.DOWNLOAD_HANDLED |
            EventDistributor.UNREAD_ITEMS_UPDATE | // sent when playback position is reset
            EventDistributor.PLAYER_STATUS_UPDATE;

    private Playlist playlist;
    private ArrayList<FeedItem> feedItemList;

    private RecyclerView recyclerView;
    private PlaylistRecyclerAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private List<Downloader> downloaderList;
    private ItemTouchHelper itemTouchHelper;
    private boolean isUpdatingFeeds = false;

    @Override
    public void onCreate(Bundle savedInstanceStats){
        super.onCreate(savedInstanceStats);
        setHasOptionsMenu(true);
        playlist = (Playlist) getArguments().getSerializable("playlist");

    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        recyclerView.setAdapter(adapter);
        EventDistributor.getInstance().register(contentUpdate);
        EventBus.getDefault().registerSticky(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        EventDistributor.getInstance().unregister(contentUpdate);
        EventBus.getDefault().unregister(this);
    }


    public void onEventMainThread(FeedItemEvent event) {
        Log.d(TAG, "onEventMainThread() called with: " + "event = [" + event + "]");
        if(playlist == null || adapter == null) {
            return;
        }
        for(int i=0, size = event.items.size(); i < size; i++) {
            FeedItem item = event.items.get(i);
            int pos = FeedItemUtil.indexOfItemWithId(feedItemList, item.getId());
            if(pos >= 0){
                feedItemList.remove(pos);
                feedItemList.add(pos, item);
                adapter.notifyItemChanged(pos);
            }
        }
    }

    public void onEventMainThread(DownloadEvent event) {
        Log.d(TAG, "onEventMainThread() called with: " + "event = [" + event + "]");
        DownloaderUpdate update = event.update;
        downloaderList = update.downloaders;
        if (isUpdatingFeeds != update.feedIds.length > 0) {
            getActivity().supportInvalidateOptionsMenu();
        }
        if (adapter != null && update.mediaIds.length > 0) {
            for (long mediaId : update.mediaIds) {
                int pos = FeedItemUtil.indexOfItemWithMediaId(feedItemList, mediaId);
                if (pos >= 0) {
                    adapter.notifyItemChanged(pos);
                }
            }
        }
    }
    private final MenuItemUtils.UpdateRefreshMenuItemChecker updateRefreshMenuItemChecker =
            () -> DownloadService.isRunning && DownloadRequester.getInstance().isDownloadingFeeds();

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if(!isAdded()) {
            return;
        }
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.playlist_context, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem){
        ItunesSuggestedFragment itunesSuggestedFragment = new ItunesSuggestedFragment();
        Bundle constructorArguments = new Bundle();
        constructorArguments.putString("playlist name", playlist.getName());
        int[] favorites = favoriteType(GenreStorage.loadGenres(getContext()));
        constructorArguments.putString("query", ""+favorites[0]+"-"+favorites[1]+"-"+favorites[2]+"");
        itunesSuggestedFragment.setArguments(constructorArguments);
        ((MainActivity)getActivity()).loadChildFragment(itunesSuggestedFragment);
        return true;
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceStats){
        View root = inflater.inflate(R.layout.playlist_fragment, container, false);
        ((MainActivity) getActivity()).getSupportActionBar().setTitle(playlist.getName());
        feedItemList = PlaylistStorage.getFeedItemsFromIds(playlist.getPodcasts());
        if(feedItemList.size() > 0){
            TextView emptyText = (TextView) root.findViewById(R.id.emptyText);
            emptyText.setVisibility(View.GONE);
        }

        recyclerView = (RecyclerView) root.findViewById(R.id.recycler_view_playlist);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        itemTouchHelper = new ItemTouchHelper(
                new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, ItemTouchHelper.RIGHT) {

                    @Override
                    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                        int fromPosition = viewHolder.getAdapterPosition();
                        int toPosition = target.getAdapterPosition();
                        Log.d(TAG, "move(" + fromPosition + ", " + toPosition + ")");
                        if(fromPosition >= feedItemList.size() || toPosition >= feedItemList.size()) {
                            return false;
                        }
                        swapFeedItems(fromPosition, toPosition);
                        adapter.notifyItemMoved(fromPosition, toPosition);
                        updatePlaylist();
                        return true;
                    }

                    @Override
                    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                        return;
                    }

                    @Override
                    public boolean isLongPressDragEnabled() {
                        return true;
                    }

                    @Override
                    public boolean isItemViewSwipeEnabled() {
                        return false;
                    }

                    @Override
                    public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int actionState) {
                        if (actionState != ItemTouchHelper.ACTION_STATE_IDLE) {
                            if (viewHolder instanceof PlaylistRecyclerAdapter.ItemTouchHelperViewHolderPlaylists) {
                                PlaylistRecyclerAdapter.ItemTouchHelperViewHolderPlaylists itemViewHolder =
                                        (PlaylistRecyclerAdapter.ItemTouchHelperViewHolderPlaylists) viewHolder;
                                itemViewHolder.onItemSelected();
                            }
                        }

                        super.onSelectedChanged(viewHolder, actionState);
                    }
                    @Override
                    public void clearView(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
                        super.clearView(recyclerView, viewHolder);

                        if (viewHolder instanceof PlaylistRecyclerAdapter.ItemTouchHelperViewHolderPlaylists) {
                            PlaylistRecyclerAdapter.ItemTouchHelperViewHolderPlaylists itemViewHolder =
                                    (PlaylistRecyclerAdapter.ItemTouchHelperViewHolderPlaylists) viewHolder;
                            itemViewHolder.onItemClear();
                        }
                    }
                });

        itemTouchHelper.attachToRecyclerView(recyclerView);

        adapter = new PlaylistRecyclerAdapter(feedItemList, getActivity().getApplicationContext(),(MainActivity)getActivity(), itemAccess, new DefaultActionButtonCallback(getActivity()),itemTouchHelper);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new PlaylistRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                MainActivity activity = (MainActivity) getActivity();
                if (activity != null) {
                    long itemId = adapter.getSelectedItem(position).getId();
                    activity.loadChildFragment(ItemFragment.newInstance(itemId));
                }
            }
        });

        adapter.setOnLongItemClickListener(new PlaylistRecyclerAdapter.OnItemLongClickListener(){
            @Override
            public boolean onItemLongClick(int position) {
                AlertDialog.Builder podcastOptions = new AlertDialog.Builder(getActivity());
                podcastOptions.setTitle(feedItemList.get(position).getTitle());
                podcastOptions.setItems(R.array.podcast_options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String temp[] = getResources().getStringArray(R.array.podcast_options);
                        if(temp[which].equals("Remove Podcast")){
                            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setMessage("Remove podcast " + feedItemList.get(position).getTitle() + " from playlist " + playlist.getName() + "?")
                                    .setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            ArrayList<Playlist> playlists = PlaylistStorage.loadPlaylists(getContext());

                                            playlist.removePodcast(feedItemList.get(position).getId());
                                            for(Playlist temp: playlists){
                                                if(temp.getName().equals(playlist.getName())){
                                                    playlists.remove(temp);
                                                    playlists.add(playlist);
                                                    PlaylistStorage.savePlaylists(playlists, getActivity().getApplicationContext());
                                                    feedItemList.remove(feedItemList.get(position));
                                                    adapter.notifyDataSetChanged();
                                                    break;
                                                }
                                            }
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            //do nothing
                                        }
                                    });

                            AlertDialog removeDialog = builder.create();
                            removeDialog.show();
                        }
                    }
                });


                podcastOptions.show();
                return false;
            }
        });

        FloatingActionButton playButton = (FloatingActionButton) root.findViewById(R.id.playButton);
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            //Onclick functionality for the floating play button
            public void onClick(View v) {
                onClickPlayAll(v, feedItemList, playlist);
            }
        });

        FloatingActionButton shufflePlayButton = (FloatingActionButton) root.findViewById(R.id.shuffleButton);
        shufflePlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            //Onclick functionality for the floating play button
            public void onClick(View v) {
                onClickShufflePlay(v, feedItemList, playlist);
            }
        });

        Button downloadAll = (Button) root.findViewById(R.id.downloadAll);
        downloadAll.setOnClickListener(v -> {
            downloadAll();
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("PodCast Download in progress")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });


            AlertDialog downloadDialog = builder.create();
            downloadDialog.show();


        });

        return root;
    }
    public void downloadAll()
    {
        for( FeedItem cast : feedItemList)
        {
            try {
                DBTasks.downloadFeedItems(getContext(), cast);
            } catch (DownloadRequestException e)
            {
                e.printStackTrace();
                DownloadRequestErrorDialogCreator.newRequestErrorDialog(getContext(), e.getMessage());
            }
        }
    }

    public void onClickPlayAll(View v, ArrayList<FeedItem> feedItemList, Playlist playlist){
        //Verify that there are items in the playlist
        if(feedItemList.size() <= 0) {
            Log.d(TAG, "No media items to play.");
            Snackbar mySnackbar = Snackbar.make(v, "No episodes to play", Snackbar.LENGTH_LONG);
            mySnackbar.show();
            return;
        }
        //Empty current Queue
        clearQueue();
        Log.d(TAG, "Queue cleared");
        //Add playlist songs to the queue

        //We need a long[] of feeditemids to pass to the queue.
        Long[] tempArr = playlist.getPodcasts().toArray(new Long[0]);
        long[] podcastids = new long[tempArr.length];
        for (int i = 0; i < tempArr.length; i++) {
            podcastids[i] = tempArr[i];
        }

        addItemsToQueue(podcastids);
        Log.d(TAG, "Added " + podcastids.length + " items to the queue");

        //Play the queue from start - stream
        FeedItem item;
        if(feedItemList.size() > 0){
            item = feedItemList.get(0);
            if (item.hasMedia()) {
                FeedMedia media = item.getMedia();
                playMedia(media);
            }
        } else {
            Log.d(TAG, "No media item to play.");
            return;
        }
    }

    /*
    Shuffles the playlist items before playing.
     */
    public void onClickShufflePlay(View v, ArrayList<FeedItem> feedItemList, Playlist playlist){
        //Verify that there are items in the playlist
        if(feedItemList.size() <= 0) {
            Log.d(TAG, "No media items to play.");
            Snackbar mySnackbar = Snackbar.make(v, "No episodes to play", Snackbar.LENGTH_LONG);
            mySnackbar.show();
            return;
        }
        //Empty current Queue
        clearQueue();
        Log.d(TAG, "Queue cleared");
        //Add playlist songs to the queue

        //We need a long[] of feeditemids to pass to the queue.
        Long[] tempArr = playlist.getPodcasts().toArray(new Long[0]);
        long[] podcastids = new long[tempArr.length];
        for (int i = 0; i < tempArr.length; i++) {
            podcastids[i] = tempArr[i];
        }

        //SHUFFLE the podcastids array before adding to the queue.
        shuffle(podcastids);

        addItemsToQueue(podcastids);
        Log.d(TAG, "Added " + podcastids.length + " items to the queue");

        //Play the queue from start - stream
        FeedItem item = null;
        if(feedItemList.size() > 0){
            for(FeedItem i : feedItemList) {
                if(i.getId() == podcastids[0]) {
                    item = i;
                    break;
                }
            }
            if(item != null){
                if (item.hasMedia()) {
                    FeedMedia media = item.getMedia();
                    playMedia(media);
                }
            } else {
                Log.e(TAG, "No media item to play, some error occurred");
            }
        } else {
            Log.d(TAG, "No media item to play.");
            return;
        }
    }

    public void clearQueue(){
        DBWriter.clearQueue();
    }

    public int[] favoriteType( HashMap<String,int[]> stored)
    {
        int[] favorites = new int[3];
        Log.d(TAG,"popular method was called");
        favorites[0]=0;
        favorites[1]=0;
        favorites[2]=0;
        int max=0;
        int second=0;
        int third=0;
        HashMap<Integer, Integer> count = new HashMap<Integer,Integer>();
        for(FeedItem element : feedItemList)
        {
            String key = element.getFeed().getTitle();
            for(int genreId : stored.get(key)) {
                if(genreId == 26)
                {
                    //this is the default podcast id that all podcasts share
                    //no need to count these
                }

                else
                if (count.get(genreId) == null) {
                    count.put(genreId, 1);
                    if(max==0)
                    {
                        max=1;
                        favorites[0]=genreId;
                    }
                    if(max==1)
                    {
                        if(favorites[1]!=0&&favorites[2]==0)
                        {
                            third=1;
                            favorites[2]=genreId;
                        }
                        else {
                            if(favorites[0]!=genreId){
                                second=1;
                                favorites[1] = genreId;
                            }
                        }
                    }
                } else {
                    int current = count.get(genreId);
                    count.put(genreId, current + 1);
                    if (current + 1 > max) {
                        max = current + 1;
                        favorites[0] = genreId;
                    }
                    else
                    if (current + 1 > second) {
                        second = current + 1;
                        favorites[1] = genreId;
                    }
                    else
                    if (current + 1 > third) {
                        third = current + 1;
                        favorites[2] = genreId;
                    }

                }
            }
        }



        return favorites;
    }

    public void addItemsToQueue(long... podcastids){
        DBWriter.addQueueItem(getContext(), false, podcastids);
    }

    public void playMedia(FeedMedia media){
        DBTasks.playMedia(getActivity(), media, true, true, true);
    }

    public void swapFeedItems(int fromPosition, int toPosition){
        Collections.swap(feedItemList,fromPosition, toPosition);
    }

    public void updatePlaylist(){
        ArrayList<Playlist> playlists = PlaylistStorage.loadPlaylists(getContext());
        ArrayList<Long> feedItemIds = new ArrayList<>();
        for(FeedItem item : feedItemList){
            feedItemIds.add(item.getId());
        }
        playlist.setPodcasts(feedItemIds);
        Playlist toRemove = null;
        for(Playlist temp: playlists){
            if(temp.getName().equals(playlist.getName()))
                toRemove = temp;
        }
        playlists.remove(toRemove);
        playlists.add(playlist);
        PlaylistStorage.savePlaylists(playlists, getActivity().getApplicationContext());
    }

    //For testing purposes only
    public void setFeedItemListForTestingOnly(ArrayList<FeedItem> feedItems){
        this.feedItemList = feedItems;
    }

    public ArrayList<FeedItem> getFeedItemList(){
        return feedItemList;
    }

    private PlaylistRecyclerAdapter.ItemAccess itemAccess = new PlaylistRecyclerAdapter.ItemAccess() {
        @Override
        public int getCount() {
            return feedItemList != null ? feedItemList.size() : 0;
        }

        @Override
        public FeedItem getItem(int position) {
            if (feedItemList != null && 0 <= position && position < feedItemList.size()) {
                return feedItemList.get(position);
            }
            return null;
        }

        @Override
        public long getItemDownloadedBytes(FeedItem item) {
            if (downloaderList != null) {
                for (Downloader downloader : downloaderList) {
                    if (downloader.getDownloadRequest().getFeedfileType() == FeedMedia.FEEDFILETYPE_FEEDMEDIA
                            && downloader.getDownloadRequest().getFeedfileId() == item.getMedia().getId()) {
                        Log.d(TAG, "downloaded bytes: " + downloader.getDownloadRequest().getSoFar());
                        return downloader.getDownloadRequest().getSoFar();
                    }
                }
            }
            return 0;
        }

        @Override
        public long getItemDownloadSize(FeedItem item) {
            if (downloaderList != null) {
                for (Downloader downloader : downloaderList) {
                    if (downloader.getDownloadRequest().getFeedfileType() == FeedMedia.FEEDFILETYPE_FEEDMEDIA
                            && downloader.getDownloadRequest().getFeedfileId() == item.getMedia().getId()) {
                        Log.d(TAG, "downloaded size: " + downloader.getDownloadRequest().getSize());
                        return downloader.getDownloadRequest().getSize();
                    }
                }
            }
            return 0;
        }
        @Override
        public int getItemDownloadProgressPercent(FeedItem item) {
            if (downloaderList != null) {
                for (Downloader downloader : downloaderList) {
                    if (downloader.getDownloadRequest().getFeedfileType() == FeedMedia.FEEDFILETYPE_FEEDMEDIA
                            && downloader.getDownloadRequest().getFeedfileId() == item.getMedia().getId()) {
                        return downloader.getDownloadRequest().getProgressPercent();
                    }
                }
            }
            return 0;
        }

        @Override
        public LongList getQueueIds() {
            return feedItemList != null ? LongList.of(FeedItemUtil.getIds(feedItemList)) : new LongList(0);
        }
    };

    private EventDistributor.EventListener contentUpdate = new EventDistributor.EventListener() {
        @Override
        public void update(EventDistributor eventDistributor, Integer arg) {
            if ((arg & EVENTS) != 0) {
                Log.d(TAG, "arg: " + arg);
                if (isUpdatingFeeds != updateRefreshMenuItemChecker.isRefreshing()) {
                    getActivity().supportInvalidateOptionsMenu();
                }
            }
        }
    };


}
