package de.danoeh.antennapod.fragment.itunes;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.adapter.itunes.ItunesCategoriesAdapter;

import android.support.v4.app.Fragment;
import android.widget.GridView;
import java.util.Arrays;
import java.util.List;

public class ItunesCategoriesFragment extends Fragment {

    public static final String TAG = "ItunesCategoriesFragment";

    private ItunesCategoriesAdapter adapter;
    private GridView gridView;
    private List<String> categories;

    @Override
    public void onCreate(Bundle savedInstanceStats){
        super.onCreate(savedInstanceStats);

        String[] categoriesArray = getResources().getStringArray(R.array.itunes_categories);
        categories = Arrays.asList(categoriesArray);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceStats){
        View root = inflater.inflate(R.layout.itunes_categories, container, false);
        gridView = (GridView) root.findViewById(R.id.gridView);
        adapter = new ItunesCategoriesAdapter(categories);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            MainActivity activity = (MainActivity) getActivity();
            activity.loadChildFragment(ItunesSearchFragment.newInstance(categories.get(position)));

        });
        return root;
    }
}
