package de.danoeh.antennapod.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.glide.ApGlideSettings;
import jp.shts.android.library.TriangleLabelView;

public class FilteredSubscriptionsAdapter extends BaseAdapter {

    private MainActivity mainActivity;
    private SubscriptionsAdapter.ItemAccess itemAccess;

    public FilteredSubscriptionsAdapter(MainActivity mainActivity, SubscriptionsAdapter.ItemAccess itemAccess) {
        this.mainActivity = mainActivity;
        this.itemAccess = itemAccess;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) mainActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.subscription_item, parent, false);
        }

        Feed feed = itemAccess.getItem(position);

        if (feed == null)
            return convertView;

        TextView feedTitle = (TextView) convertView.findViewById(R.id.txtvTitle);
        ImageView imageView = (ImageView) convertView.findViewById(R.id.imgvCover);
        TriangleLabelView count = (TriangleLabelView) convertView.findViewById(R.id.triangleCountView);

        feedTitle.setText(feed.getTitle());

        int numOfEpisodes = itemAccess.getFeedCounter(feed.getId());
        if(numOfEpisodes > 0) {
            count.setPrimaryText(String.valueOf(numOfEpisodes));
            count.setVisibility(View.VISIBLE);
        } else {
            count.setVisibility(View.GONE);
        }

        Glide.with(mainActivity)
                .load(feed.getImageLocation())
                .error(R.color.light_gray)
                .diskCacheStrategy(ApGlideSettings.AP_DISK_CACHE_STRATEGY)
                .fitCenter()
                .dontAnimate()
                .into(new CoverTarget(null, feedTitle, imageView, mainActivity));

        return convertView;
    }

    @Override
    public Object getItem(int position) {
        return itemAccess.getItem(position);
    }

    @Override
    public long getItemId(int position) {
        return itemAccess.getItem(position).getId();
    }

    @Override
    public int getCount() {
        return itemAccess.getCount();
    }
}
