package de.danoeh.antennapod.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.adapter.FilteredSubscriptionsAdapter;
import de.danoeh.antennapod.adapter.SubscriptionsAdapter;

public class FilteredSubscriptionsFragment extends Fragment {

    private GridView subscriptionGridLayout;
    private FilteredSubscriptionsAdapter adapter;
    private SubscriptionsAdapter.ItemAccess itemAccess;

    public FilteredSubscriptionsFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_subscriptions, container, false);
        adapter = new FilteredSubscriptionsAdapter((MainActivity) getActivity(), itemAccess);
        subscriptionGridLayout = (GridView) root.findViewById(R.id.subscriptions_grid);
        subscriptionGridLayout.setAdapter(adapter);
        subscriptionGridLayout.setOnItemClickListener((parent, view, position, id) -> {
            Fragment fragment = ItemlistFragment.newInstance(adapter.getItemId(position));
            ((MainActivity) getActivity()).loadChildFragment(fragment);
        });
        return root;
    }

    public FilteredSubscriptionsAdapter getAdapter() {
        return adapter;
    }

    public void setAdapter(FilteredSubscriptionsAdapter adapter) {
        this.adapter = adapter;
        subscriptionGridLayout.setAdapter(adapter);
    }

    public SubscriptionsAdapter.ItemAccess getItemAccess() {
        return itemAccess;
    }

    public void setItemAccess(SubscriptionsAdapter.ItemAccess itemAccess) {
        this.itemAccess = itemAccess;
    }
}
