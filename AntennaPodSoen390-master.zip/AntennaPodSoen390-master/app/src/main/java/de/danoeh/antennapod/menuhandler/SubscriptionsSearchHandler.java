package de.danoeh.antennapod.menuhandler;

import android.support.v7.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import de.danoeh.antennapod.activity.MainActivity;
import de.danoeh.antennapod.adapter.SubscriptionsAdapter;
import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.storage.DBReader;
import de.danoeh.antennapod.core.storage.FeedSearcher;
import de.danoeh.antennapod.fragment.FilteredSubscriptionsFragment;

public class SubscriptionsSearchHandler implements SearchView.OnQueryTextListener {

    private MainActivity mainActivity;
    private SearchView searchField;

    private DBReader.NavDrawerData subscriptions;
    private List<Feed> filteredSubscriptions = new ArrayList<>();

    private SubscriptionsAdapter.ItemAccess itemAccess = new SubscriptionsAdapter.ItemAccess() {
        @Override
        public int getCount() {
            return filteredSubscriptions.size();
        }

        @Override
        public Feed getItem(int position) {
            return filteredSubscriptions.get(position);
        }

        @Override
        public int getFeedCounter(long feedId) {
            return 0;
        }
    };

    public SubscriptionsSearchHandler(MainActivity mainActivity, SearchView searchField) {
        this.mainActivity = mainActivity;
        this.searchField = searchField;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        subscriptions = DBReader.getNavDrawerData();
        findSubscriptions(query.trim().toLowerCase());
        searchField.clearFocus();

        if (filteredSubscriptions.size() != 0) {
            FilteredSubscriptionsFragment fragment = new FilteredSubscriptionsFragment();
            fragment.setItemAccess(itemAccess);
            mainActivity.loadChildFragment(fragment);
            return true;
        } else {
            Toast.makeText(mainActivity, "No results found for " + query.trim(), Toast.LENGTH_LONG).show();
            searchField.setQuery("", false);
            searchField.setIconified(true);
            return false;
        }
    }

    public void findSubscriptions(String query) {
        for (Feed feed : subscriptions.feeds)
            if (feed.getTitle() != null && feed.getTitle().toLowerCase().contains(query))
                filteredSubscriptions.add(feed);
            else if (feed.getAuthor() != null && feed.getAuthor().toLowerCase().contains(query))
                filteredSubscriptions.add(feed);
            else if (feed.getDescription() != null && feed.getDescription().toLowerCase().contains(query))
                filteredSubscriptions.add(feed);
            else if (searchFeedItems(feed, query))
                filteredSubscriptions.add(feed);

    }

    public boolean searchFeedItems(Feed feed, String query) {
        return !FeedSearcher.performSearch(mainActivity, query, feed.getId()).isEmpty();
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        return false;
    }

    public void setSubscriptions(DBReader.NavDrawerData subscriptions) {
        this.subscriptions = subscriptions;
    }

    public List<Feed> getFilteredSubscriptions() {
        return filteredSubscriptions;
    }

    public void setFilteredSubscriptions(List<Feed> filteredSubscriptions) {
        this.filteredSubscriptions = filteredSubscriptions;
    }

}
