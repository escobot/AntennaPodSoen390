package de.danoeh.antennapod.adapter.itunes;


import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.List;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.MainActivity;

import static de.danoeh.antennapod.adapter.itunes.ItunesAdapter.Podcast;

public class SuggestedAdapter extends ArrayAdapter<Podcast> {

    private final Context context;
    private final List<Podcast> data;

    public SuggestedAdapter(Context context, List<Podcast> podcasts){
        super(context,0,podcasts);
        this.context = context;
        this.data = podcasts;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {

        Podcast podcast = data.get(position);
        SuggestedPodcastViewHolder viewHolder;
        View view;

        if(convertView == null) {
            view = ((MainActivity) context).getLayoutInflater()
                    .inflate(R.layout.itunes_podcast_listitem, parent, false);
            viewHolder = new SuggestedPodcastViewHolder(view);
            view.setTag(viewHolder);
        } else {
            view = convertView;
            viewHolder = (SuggestedPodcastViewHolder) view.getTag();
        }

        viewHolder.titleView.setText(podcast.title);
        if(podcast.feedUrl != null && !podcast.feedUrl.contains("itunes.apple.com")) {
            viewHolder.urlView.setText(podcast.feedUrl);
            viewHolder.urlView.setVisibility(View.VISIBLE);
        } else {
            viewHolder.urlView.setVisibility(View.GONE);
        }

        Glide.with(context)
                .load(podcast.imageUrl)
                .placeholder(R.color.light_gray)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .fitCenter()
                .dontAnimate()
                .into(viewHolder.coverView);

        return view;
    }

    //Viewholder is a copy of PodcastViewHolder but specific to the suggested podcastFragment
    class SuggestedPodcastViewHolder {
        final ImageView coverView;
        final TextView titleView;
        final TextView urlView;

        SuggestedPodcastViewHolder(View view){
            coverView = (ImageView) view.findViewById(R.id.imgvCover);
            titleView = (TextView) view.findViewById(R.id.txtvTitle);
            urlView = (TextView) view.findViewById(R.id.txtvUrl);
        }
    }
}
