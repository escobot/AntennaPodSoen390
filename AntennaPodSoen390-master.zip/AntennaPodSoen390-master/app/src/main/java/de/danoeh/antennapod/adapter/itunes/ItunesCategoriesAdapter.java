package de.danoeh.antennapod.adapter.itunes;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;

import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import de.danoeh.antennapod.R;

public class ItunesCategoriesAdapter extends BaseAdapter {

    private List<String> categoriesList;

    public ItunesCategoriesAdapter(List<String> categoriesList){
        this.categoriesList = categoriesList;
    }

    @Override
    public int getCount() {
        return categoriesList.size();
    }

    @Override
    public Object getItem(int position) {
        return categoriesList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = convertView;
        if(view == null)
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itunes_categories_item, parent, false);

        TextView text = (TextView) view.findViewById(R.id.text_id);
        text.setText(categoriesList.get(position));

        return view;
    }
}
