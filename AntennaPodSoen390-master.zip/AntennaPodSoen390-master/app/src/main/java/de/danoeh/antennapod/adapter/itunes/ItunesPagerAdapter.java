package de.danoeh.antennapod.adapter.itunes;

import android.content.res.Resources;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import de.danoeh.antennapod.fragment.itunes.ItunesCategoriesFragment;
import de.danoeh.antennapod.fragment.itunes.ItunesSearchFragment;

public class ItunesPagerAdapter extends FragmentPagerAdapter {

    private static final int NUM_PAGES = 2;

    Resources resources;

    public ItunesPagerAdapter(FragmentManager fm, Resources resources){
        super(fm);

        this.resources = resources;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position){
            case 0:
                return new ItunesSearchFragment();
            case 1:
                return new ItunesCategoriesFragment();
            default:
                return null;
        }
    }

    @Override
    public CharSequence getPageTitle(int position){
        switch(position){
            case 0:
                return "Top";
            case 1:
                return "Categories";
            default:
                return null;
        }
    }


    @Override
    public int getCount() {
        return NUM_PAGES;
    }
}
