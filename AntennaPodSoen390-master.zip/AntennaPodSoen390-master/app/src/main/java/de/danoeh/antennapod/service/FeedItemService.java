package de.danoeh.antennapod.service;

import java.util.Date;

import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.storage.DBWriter;
import de.danoeh.antennapod.core.util.DateUtils;

/**
 * Intermediary class between app:adapters and the core components
 */
public class FeedItemService {

    /**
     * Updates the last played date for a FeedItem
     * @param item to update the last played date
     */
    public static void updateLastPlayedDate(FeedItem item) {
        Date today = new Date();
        // make sure the not to update the date if it has been already updated
        if(today.after(item.getLastPlayed()) && !DateUtils.isSameDay(item.getLastPlayed(), today)) {
            item.setLastPlayed(today);
            DBWriter.setFeedItemLastPlayed(item, today);
        }
    }

}
