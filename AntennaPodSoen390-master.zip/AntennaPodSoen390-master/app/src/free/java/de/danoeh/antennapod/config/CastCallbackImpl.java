package de.danoeh.antennapod.config;

import de.danoeh.antennapod.core.CastCallbacks;

public class CastCallbackImpl implements CastCallbacks {

}
