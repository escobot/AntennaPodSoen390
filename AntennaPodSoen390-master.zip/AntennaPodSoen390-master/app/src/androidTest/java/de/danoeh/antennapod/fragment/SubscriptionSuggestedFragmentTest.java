package de.danoeh.antennapod.fragment;

import junit.framework.TestCase;

public class SubscriptionSuggestedFragmentTest extends TestCase {
    public void testSplitQuery() throws Exception {
    }

}