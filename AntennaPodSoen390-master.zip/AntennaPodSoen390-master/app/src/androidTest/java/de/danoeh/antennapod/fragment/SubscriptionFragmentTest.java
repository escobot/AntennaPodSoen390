package de.danoeh.antennapod.fragment;

import junit.framework.TestCase;

import org.junit.Test;

import static org.mockito.Mockito.spy;


public class SubscriptionFragmentTest extends TestCase {
    SubscriptionFragment fragment = spy(SubscriptionFragment.class);
    String[] categoriesArray = {"Arts", "Business", "Comedy", "Crime", "Education"};
    String noQueries = "osuho osatuot soauhoauht osuaonetuhoa souaeuhnoae u";
    String oneQuery = "aoeuhso oaesunhatohu saouthon aosutohau Comedy uasoeuthaou";
    String twoQueries = "auonth oauhons Comedy oausth stushaou arts";
    String connectedQuery = "aoeueu comedy-central oaeuaoeu teuh onu";

    @Test
    public void testGetSuggestedQuery() throws Exception {
        assertEquals("", fragment.getSuggestedQuery(noQueries, categoriesArray));
        assertEquals("comedy", fragment.getSuggestedQuery(oneQuery, categoriesArray));
        assertEquals("comedy arts", fragment.getSuggestedQuery(twoQueries, categoriesArray));
        assertEquals("comedy", fragment.getSuggestedQuery(connectedQuery, categoriesArray));
    }

}