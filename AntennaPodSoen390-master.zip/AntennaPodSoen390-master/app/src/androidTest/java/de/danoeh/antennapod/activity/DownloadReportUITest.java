package de.danoeh.antennapod.activity;


import android.support.test.espresso.DataInteraction;
import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsInstanceOf;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import de.danoeh.antennapod.R;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.pressImeActionButton;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withClassName;
import static android.support.test.espresso.matcher.ViewMatchers.withContentDescription;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.is;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class DownloadReportUITest {

    @Rule
    public ActivityTestRule<SplashActivity> mActivityTestRule = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void downloadReportUITest() {
        // Added a sleep statement to match the app's execution delay.
        // The recommended way to handle such scenarios is to use Espresso idling resources:
        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        try {
            ViewInteraction appCompatImageButton = onView(
                    allOf(withContentDescription("Open menu"),
                            childAtPosition(
                                    allOf(withId(R.id.toolbar),
                                            childAtPosition(
                                                    allOf(withId(R.id.content),
                                                            childAtPosition(
                                                                    withId(R.id.drawer_layout),
                                                                    0)),
                                                    1)),
                                    1),
                            isDisplayed()));
            appCompatImageButton.perform(click());
        } catch (Exception e){
            //do nothing, skip this step
        }

        DataInteraction relativeLayout = onData(anything())
                .inAdapterView(allOf(withId(R.id.nav_list),
                        childAtPosition(
                                allOf(withId(R.id.nav_layout),
                                        childAtPosition(
                                                withId(R.id.drawer_layout),
                                                1)),
                                2)))
                .atPosition(5);
        relativeLayout.perform(click());

        ViewInteraction appCompatEditText2 = onView(
                allOf(withId(R.id.etxtFeedurl),
                        childAtPosition(
                                childAtPosition(
                                        childAtPosition(
                                                withId(R.id.main_view),
                                                0),
                                        0),
                                7)));
        appCompatEditText2.perform(scrollTo(), replaceText("rss.art19.com/the-daily"), closeSoftKeyboard());

        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction appCompatEditText3 = onView(
                allOf(withId(R.id.etxtFeedurl), withText("rss.art19.com/the-daily"),
                        childAtPosition(
                                childAtPosition(
                                        childAtPosition(
                                                withId(R.id.main_view),
                                                0),
                                        0),
                                7)));
        appCompatEditText3.perform(pressImeActionButton());

        ViewInteraction appCompatButton2 = onView(
                allOf(withId(R.id.butConfirm), withText("Confirm"),
                        childAtPosition(
                                childAtPosition(
                                        childAtPosition(
                                                withId(R.id.main_view),
                                                0),
                                        0),
                                8)));
        appCompatButton2.perform(scrollTo(), click());

        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction appCompatButton3 = onView(
                allOf(withId(R.id.butSubscribe), withText("Subscribe"),
                        childAtPosition(
                                childAtPosition(
                                        withParent(withId(R.id.listview)),
                                        3),
                                1),
                        isDisplayed()));
        appCompatButton3.perform(click());

        // Added a sleep statement to match the app's execution delay.
        // The recommended way to handle such scenarios is to use Espresso idling resources:
        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction appCompatButton4 = onView(
                allOf(withId(R.id.butSubscribe), withText("Open Podcast"),
                        childAtPosition(
                                childAtPosition(
                                        withParent(withId(R.id.listview)),
                                        3),
                                1),
                        isDisplayed()));
        appCompatButton4.perform(click());

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        DataInteraction linearLayout = onData(anything())
                .inAdapterView(allOf(withId(android.R.id.list),
                        childAtPosition(
                                childAtPosition(
                                        withClassName(is("android.widget.FrameLayout")),
                                        1),
                                1)))
                .atPosition(1);
        linearLayout.perform(click());

        // Added a sleep statement to match the app's execution delay.
        // The recommended way to handle such scenarios is to use Espresso idling resources:
        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction iconButton = onView(
                allOf(withId(R.id.butAction1), withText("\uE2C4  Download"),
                        childAtPosition(
                                childAtPosition(
                                        allOf(withId(R.id.header),
                                                childAtPosition(
                                                        withId(R.id.content_root),
                                                        0)),
                                        2),
                                0),
                        isDisplayed()));
        iconButton.perform(click());

        ViewInteraction mDButton = onView(
                allOf(withId(R.id.md_buttonDefaultPositive), withText("Allow temporarily"),
                        childAtPosition(
                                childAtPosition(
                                        allOf(withId(android.R.id.content),
                                                childAtPosition(
                                                        withClassName(is("android.widget.LinearLayout")),
                                                        1)),
                                        0),
                                4),
                        isDisplayed()));
        mDButton.perform(click());

        // Added a sleep statement to match the app's execution delay.
        // The recommended way to handle such scenarios is to use Espresso idling resources:
        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction textView = onView(
                allOf(withId(android.R.id.title), withText("Download Report"),
                        childAtPosition(
                                allOf(IsInstanceOf.<View>instanceOf(android.widget.LinearLayout.class),
                                        childAtPosition(
                                                allOf(IsInstanceOf.<View>instanceOf(android.widget.LinearLayout.class),
                                                        childAtPosition(
                                                                IsInstanceOf.<View>instanceOf(android.widget.FrameLayout.class),
                                                                1)),
                                                0)),
                                0),
                        isDisplayed()));

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
