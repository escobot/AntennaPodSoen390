package de.test.antennapod.util;

import android.test.InstrumentationTestCase;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.storage.DBReader;
import de.danoeh.antennapod.core.storage.PodDBAdapter;
import de.danoeh.antennapod.core.util.FeedItemLookupMap;

import static de.test.antennapod.storage.DBTestUtils.saveFeedlist;

public class FeedItemLookupMapTest extends InstrumentationTestCase {

    @Override
    protected void tearDown() throws Exception {

        // wipe the database after running the tests
        super.tearDown();
        assertTrue(PodDBAdapter.deleteDatabase());
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();

        // create new database
        PodDBAdapter.init(getInstrumentation().getTargetContext());
        PodDBAdapter.deleteDatabase();
        PodDBAdapter adapter = PodDBAdapter.getInstance();
        adapter.open();
        adapter.close();
    }

    public void testGetInstance() {
        // Create fake download items
        saveDownloadedItems(10);
        List<FeedItem> downloaded_saved = DBReader.getDownloadedItems();
        assertNotNull(downloaded_saved);

        // Create the lookup map
        Map<String, Integer> lookupMap = FeedItemLookupMap.getInstance();
        assertNotNull(lookupMap);

        // Assert lookup map has all downloadItems
        for (FeedItem item : downloaded_saved) {
            assertTrue(lookupMap.containsKey(item.getTitle()));
        }
    }

    private void saveDownloadedItems(int numItems) {
        if (numItems <= 0) {
            throw new IllegalArgumentException("numItems<=0");
        }
        List<Feed> feeds = saveFeedlist(numItems, numItems, true);
        List<FeedItem> items = new ArrayList<>();
        for (Feed f : feeds) {
            items.addAll(f.getItems());
        }
        List<FeedItem> downloaded = new ArrayList<>();
        Random random = new Random();

        while (downloaded.size() < numItems) {
            int i = random.nextInt(numItems);
            if (!downloaded.contains(items.get(i))) {
                FeedItem item = items.get(i);
                item.getMedia().setDownloaded(true);
                item.getMedia().setFile_url("file" + i);
                downloaded.add(item);
            }
        }
        PodDBAdapter adapter = PodDBAdapter.getInstance();
        adapter.open();
        adapter.setFeedItemlist(downloaded);
        adapter.close();
    }
}
