package de.test.antennapod.fragment;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.playlist.Playlist;
import de.danoeh.antennapod.core.playlist.PlaylistGeneratorHandler;
import de.danoeh.antennapod.fragment.PlaylistCategoriesFragment;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


public class PlaylistCategoriesFragmentTest extends TestCase {

    private PlaylistCategoriesFragment playlistCategoriesFragment = spy(PlaylistCategoriesFragment.class);
    private PlaylistGeneratorHandler mockPlaylistGenerator = mock(PlaylistGeneratorHandler.class);
    private Playlist mockPlaylist = mock(Playlist.class);
    private List<Integer> medicineCodes = new ArrayList<>();
    private List<Integer> comedyCodes = new ArrayList<>();
    private List<Feed> medicineFeeds = new ArrayList<>();
    private List<FeedItem> medicineFeedItems = new ArrayList<>();
    private Feed medicinePodcast = mock(Feed.class);
    private FeedItem medicinePodcastEpisode1 = mock(FeedItem.class);
    private FeedItem medicinePodcastEpisode2 = mock(FeedItem.class);
    private FeedItem medicinePodcastEpisode3 = mock(FeedItem.class);

    @Override
    public void setUp() throws Exception {
        super.setUp();

        List<String> categories = new ArrayList<>();
        categories.add("Arts");
        categories.add("Business");
        categories.add("Comedy");
        categories.add("Medicine");
        categories.add("Music");
        categories.add("Science");
        categories.add("Sports");
        categories.add("Technology");

        playlistCategoriesFragment.setItemsForTestingOnly(categories, mockPlaylistGenerator, mockPlaylist);

        //These codes are for the specific genres, see arrays.xml
        medicineCodes.add(1478);
        medicineCodes.add(1315);
        comedyCodes.add(1303);

        medicineFeeds.add(medicinePodcast);
        medicineFeedItems.add(medicinePodcastEpisode1);
        medicineFeedItems.add(medicinePodcastEpisode2);
        medicineFeedItems.add(medicinePodcastEpisode3);
    }


    public void testingThatFeedItemsAreFoundAndAddedToPodcastOnQuery() throws Exception {
        doReturn(new int[]{1478,1315}).when(playlistCategoriesFragment).getCategoryCodesFromQuery("Medicine");
        when(mockPlaylistGenerator.setSortedFeeds(medicineCodes)).thenReturn(medicineFeeds);
        doReturn(medicineFeedItems).when(playlistCategoriesFragment).fetchFeedItemsFromDB(medicinePodcast);
        doNothing().when(playlistCategoriesFragment).displayErrorMessage("Added Medicine feed items");

        playlistCategoriesFragment.generatePlaylistFromQuery(3);

        verify(playlistCategoriesFragment).getCategoryCodesFromQuery("Medicine");
        verify(mockPlaylistGenerator).clearFeeds();
        verify(mockPlaylistGenerator).setSortedFeeds(medicineCodes);
        verify(playlistCategoriesFragment).fetchFeedItemsFromDB(medicinePodcast);

        verify(mockPlaylist).addPodcast(medicinePodcastEpisode1);
        verify(mockPlaylist).addPodcast(medicinePodcastEpisode2);
        verify(mockPlaylist).addPodcast(medicinePodcastEpisode3);
        verify(playlistCategoriesFragment).displayErrorMessage("Added Medicine feed items");
    }

    public void testingThatNoFeedItemsAreFoundIfNoneOfThatGenreSubscribed() throws Exception {
        List<Feed> emptyList = new ArrayList<>();

        doReturn(new int[]{1303}).when(playlistCategoriesFragment).getCategoryCodesFromQuery("Comedy");
        when(mockPlaylistGenerator.setSortedFeeds(comedyCodes)).thenReturn(emptyList);
        doNothing().when(playlistCategoriesFragment).displayErrorMessage("No podcasts found under the category: Comedy");

        playlistCategoriesFragment.generatePlaylistFromQuery(2);

        verify(playlistCategoriesFragment).getCategoryCodesFromQuery("Comedy");
        verify(mockPlaylistGenerator).clearFeeds();
        verify(mockPlaylistGenerator).setSortedFeeds(comedyCodes);

        verify(playlistCategoriesFragment).displayErrorMessage("No podcasts found under the category: Comedy");
    }
}