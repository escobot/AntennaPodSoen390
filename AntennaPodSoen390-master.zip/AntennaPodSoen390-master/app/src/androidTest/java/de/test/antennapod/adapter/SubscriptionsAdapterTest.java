package de.test.antennapod.adapter;

import junit.framework.TestCase;

public class SubscriptionsAdapterTest extends TestCase {

    public void testGetCount() throws Exception {
        assertEquals(0,0);
    }

}