package de.test.antennapod.fragment;

import android.test.AndroidTestCase;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;

import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.feed.FeedMedia;
import de.danoeh.antennapod.core.playlist.Playlist;
import de.danoeh.antennapod.fragment.PlaylistFragment;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PlaylistFragmentTest extends AndroidTestCase {

    private PlaylistFragment playlistFragment = spy(PlaylistFragment.class);
    private ArrayList<FeedItem> feedItems = new ArrayList<>();
    private HashMap<String,int[]> storedGenres = new HashMap<>();
    private FeedItem feedItem1 = mock(FeedItem.class);
    private FeedItem feedItem2 = mock(FeedItem.class);
    private FeedItem feedItem3 = mock(FeedItem.class);


    @Override
    public void setUp() throws Exception {
        super.setUp();
        feedItems.add(feedItem1);
        feedItems.add(feedItem2);
        feedItems.add(feedItem3);

    }

    public void testingReorderingPlaylistItemsConsecutiveItems() throws Exception {
        playlistFragment.setFeedItemListForTestingOnly(feedItems);
        playlistFragment.swapFeedItems(0,1);
        ArrayList<FeedItem> items = playlistFragment.getFeedItemList();
        assertEquals(feedItem2, items.get(0));
        assertEquals(feedItem1, items.get(1));
        assertEquals(feedItem3, items.get(2));
    }

    public void testingReorderingPlaylistItemsNonConsecutiveItems() throws Exception {
        playlistFragment.setFeedItemListForTestingOnly(feedItems);
        playlistFragment.swapFeedItems(0,2);
        ArrayList<FeedItem> items = playlistFragment.getFeedItemList();
        assertEquals(feedItem3, items.get(0));
        assertEquals(feedItem2, items.get(1));
        assertEquals(feedItem1, items.get(2));
    }


    public void testOnClickPlayAll() throws Exception {
        //to reset feed item list between tests
        PlaylistFragment spyFragment = spy(PlaylistFragment.class);

        View view = new View(getContext());

        FeedMedia media = mock(FeedMedia.class);
        when(feedItem1.hasMedia()).thenReturn(true);
        when(feedItem1.getMedia()).thenReturn(media);
        when(media.getId()).thenReturn((long)1);
        ArrayList<Long> ids = new ArrayList<>();
        ids.add((long) 1);
        ids.add((long) 2);
        ids.add((long) 3);

        Playlist playlist = mock(Playlist.class);
        when(playlist.getPodcasts()).thenReturn(ids);
        try {
            spyFragment.onClickPlayAll(view, feedItems, playlist);
        } catch (Exception e){
            /*
            Try catch statement prevents DBTasks from making problems because of testing environment.
            As long as the proper methods below are called, this test passes.
             */
        }
        verify(spyFragment).clearQueue();
        verify(spyFragment).playMedia(media);
    }

    public void testOnClickShuffleAll(){
        //to reset feed item list between tests
        PlaylistFragment spyFragment = spy(PlaylistFragment.class);

        View view = new View(getContext());

        FeedMedia media = mock(FeedMedia.class);
        when(feedItem1.hasMedia()).thenReturn(true);
        when(feedItem1.getMedia()).thenReturn(media);
        when(media.getId()).thenReturn((long)1);
        ArrayList<Long> ids = new ArrayList<>();
        for (int i = 1; i <= 13; i++){
            ids.add((long) i);
        }

        long[] podcastids = new long[ids.size()];
        for (int i = 0; i < ids.size(); i++) {
            podcastids[i] = ids.get(i);
        }

        Playlist playlist = mock(Playlist.class);
        when(playlist.getPodcasts()).thenReturn(ids);
        try {
            spyFragment.onClickShufflePlay(view, feedItems, playlist);
        } catch (Exception e){
            /*
            Try catch statement prevents DBTasks from making problems because of testing environment.
            As long as the proper methods below are called, this test passes.
             */
        }
        verify(spyFragment).clearQueue();

        //Verify that the items added to the queue were not in the initial order
        verify(spyFragment,never()).addItemsToQueue(podcastids);
    }

    public void testDownloadAll() throws Exception {

        //reset
        PlaylistFragment test = new PlaylistFragment();

        test.setFeedItemListForTestingOnly(feedItems);
        test.downloadAll();
        //verify that the the media was called in the DBTasks
        verify(feedItem1).getMedia();
        verify(feedItem2).getMedia();
        verify(feedItem3).getMedia();
    }

    public void testMostPopularGenre() throws Exception {
        //reset
        PlaylistFragment fragment = spy(PlaylistFragment.class);
        fragment.setFeedItemListForTestingOnly(feedItems);
        Feed feed1 = spy(Feed.class);
        Feed feed2 = spy(Feed.class);
        Feed feed3 = spy(Feed.class);

        when(feedItem1.getFeed()).thenReturn(feed1);
        when(feedItem2.getFeed()).thenReturn(feed2);
        when(feedItem3.getFeed()).thenReturn(feed3);

        when(feed1.getTitle()).thenReturn("business podcast1");
        when(feed2.getTitle()).thenReturn("art podcast");
        when(feed3.getTitle()).thenReturn("business podcast2");

        //for this test: id 12345 is the genre id for business and 2345 for art
        storedGenres.put("business podcast1", new int[]{1111, 12345, 2222});
        storedGenres.put("business podcast2", new int[]{1161, 12345, 22862});
        storedGenres.put("art podcast", new int[]{2345, 3456});

        assertEquals(12345,fragment.favoriteType(storedGenres)[0]);
    }

    public void testMostPopularGenreNoMajority() throws Exception {
        //reset
        PlaylistFragment fragment = spy(PlaylistFragment.class);
        fragment.setFeedItemListForTestingOnly(feedItems);
        Feed feed1 = spy(Feed.class);
        Feed feed2 = spy(Feed.class);
        Feed feed3 = spy(Feed.class);

        when(feedItem1.getFeed()).thenReturn(feed1);
        when(feedItem2.getFeed()).thenReturn(feed2);
        when(feedItem3.getFeed()).thenReturn(feed3);

        when(feed1.getTitle()).thenReturn("business podcast");
        when(feed2.getTitle()).thenReturn("art podcast");
        when(feed3.getTitle()).thenReturn("technology podcast");

        //if no majority the first genre id of the first podcast will be used
        storedGenres.put("business podcast", new int[]{1111, 12345, 2222});
        storedGenres.put("technology podcast", new int[]{1161, 16645, 22862});
        storedGenres.put("art podcast", new int[]{2345, 3456});

        assertEquals(1111,fragment.favoriteType(storedGenres)[0]);
    }

    public void testMostPopularGenreMultiple() throws Exception {
        //reset
        PlaylistFragment fragment = spy(PlaylistFragment.class);
        fragment.setFeedItemListForTestingOnly(feedItems);
        Feed feed1 = spy(Feed.class);
        Feed feed2 = spy(Feed.class);
        Feed feed3 = spy(Feed.class);

        when(feedItem1.getFeed()).thenReturn(feed1);
        when(feedItem2.getFeed()).thenReturn(feed2);
        when(feedItem3.getFeed()).thenReturn(feed3);

        when(feed1.getTitle()).thenReturn("business podcast");
        when(feed2.getTitle()).thenReturn("art podcast");
        when(feed3.getTitle()).thenReturn("technology podcast");

        //if no majority the first genre id of the first podcast will be used
        storedGenres.put("business podcast", new int[]{1111, 12345, 2222,2345});
        storedGenres.put("technology podcast", new int[]{1111, 12345, 22862,2345});
        storedGenres.put("art podcast", new int[]{2345, 1111});
        storedGenres.put("art podcast2", new int[]{0000, 1111});

        assertEquals(1111,fragment.favoriteType(storedGenres)[0]);
        assertEquals(2345,fragment.favoriteType(storedGenres)[1]);
        assertEquals(12345,fragment.favoriteType(storedGenres)[2]);
    }
}