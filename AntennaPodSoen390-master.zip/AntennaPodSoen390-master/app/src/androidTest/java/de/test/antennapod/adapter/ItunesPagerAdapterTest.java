package de.test.antennapod.adapter;

import junit.framework.TestCase;

import org.junit.Test;

import de.danoeh.antennapod.fragment.itunes.ItunesCategoriesFragment;
import de.danoeh.antennapod.adapter.itunes.ItunesPagerAdapter;
import de.danoeh.antennapod.fragment.itunes.ItunesSearchFragment;

import static org.mockito.Mockito.spy;


public class ItunesPagerAdapterTest extends TestCase {
    ItunesPagerAdapter adapter = spy(ItunesPagerAdapter.class);

    @Test
    public void testGetItem() throws Exception {
        assertTrue(adapter.getItem(0 ) instanceof ItunesSearchFragment);
        assertTrue(adapter.getItem(1) instanceof ItunesCategoriesFragment);
        assertFalse(adapter.getItem(0) instanceof ItunesCategoriesFragment);
        assertEquals(null, adapter.getItem(3));
    }

    @Test
    public void testGetPageTitle() throws Exception {
        assertEquals("Top", adapter.getPageTitle(0));
        assertEquals("Categories", adapter.getPageTitle(1));
        assertEquals(null, adapter.getPageTitle(4));
    }

}