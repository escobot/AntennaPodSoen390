package de.test.antennapod.service;

import junit.framework.TestCase;

import de.danoeh.antennapod.service.PodcastTimeService;

public class PodcastTimeServiceTest extends TestCase {

    public void testCalculatePodcastDuration()  {
        String playbackSpeed = "2.00";
        int podcastDurationMS = 600000; // 10 minutes

        String result = PodcastTimeService.calculatePodcastDuration(playbackSpeed, podcastDurationMS);
        assertEquals("00:05:00", result);
    }

    public void testCalculatePodcastTimeLeft()  {
        String playbackSpeed = "1.50";
        int podcastDurationMS = 7200000; // 2 hours
        int positionMS = 5400000; // 1,5 hours

        String result = "-" + PodcastTimeService.calculatePodcastDuration(playbackSpeed, (podcastDurationMS - positionMS));

        // 30 minutes left at 1.5X speed = 20 minutes left in real time
        assertEquals("-00:20:00", result);
    }

    public void testAverageEpisodeLength() {
        long numOfEpisodes = 5;
        long episodesTotalLength = numOfEpisodes * 1000 * 60 * 60;
        long result = PodcastTimeService.calculateAverageEpisodeLength(episodesTotalLength, numOfEpisodes);
        assertEquals(1000 * 60 * 60, result);
    }

    public void testAverageEpisodeLength_NoEpisodes() {
        long numOfEpisodes = 0;
        long episodesTotalLength = 0;
        long result = PodcastTimeService.calculateAverageEpisodeLength(episodesTotalLength, numOfEpisodes);
        assertEquals(0, result);
    }

}