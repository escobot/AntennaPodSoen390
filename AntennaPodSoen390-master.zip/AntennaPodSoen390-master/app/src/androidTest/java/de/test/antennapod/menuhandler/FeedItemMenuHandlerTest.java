package de.test.antennapod.menuhandler;

import android.content.Context;
import android.support.v4.app.FragmentManager;

import junit.framework.TestCase;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.feed.FeedMedia;
import de.danoeh.antennapod.menuhandler.FeedItemMenuHandler;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


public class FeedItemMenuHandlerTest extends TestCase {

    private FeedItemMenuHandler.MenuInterface menuInterface;

    private Context context;
    private FeedItem feedItem;
    private FragmentManager fragmentManager;
    private FeedMedia feedMedia;

    public void setUp() throws Exception {
        super.setUp();
        menuInterface = mock(FeedItemMenuHandler.MenuInterface.class);
        context = mock(Context.class);
        feedItem = mock(FeedItem.class);
        fragmentManager = mock(FragmentManager.class);
        feedMedia = mock(FeedMedia.class);
    }

    /**
     * Test visibility of Delete Download option:
     * Delete Download option is visible when the episode is downloaded
     */
    public void testOnPrepareMenu() throws Exception {
        when(feedItem.getMedia()).thenReturn(feedMedia);
        when(feedItem.getMedia().isDownloaded()).thenReturn(true);
        FeedItemMenuHandler.onPrepareMenu(menuInterface, feedItem, false, null);
        verify(menuInterface).setItemVisibility(R.id.delete_download, true);
    }

    /**
     * Test visibility of Delete Download option:
     * Delete Download option not visible when the episode is not downloaded
     */
    public void testOnPrepareMenuNegative() throws Exception {
        when(feedItem.getMedia()).thenReturn(feedMedia);
        when(feedItem.getMedia().isDownloaded()).thenReturn(false);
        FeedItemMenuHandler.onPrepareMenu(menuInterface, feedItem, false, null);
        verify(menuInterface).setItemVisibility(R.id.delete_download, false);
    }

    /**
     * Test that Delete Download is handled
     */
    public void testOnMenuItemClicked() throws Exception {
        when(feedItem.hasMedia()).thenReturn(true);
        when(feedItem.getMedia()).thenReturn(feedMedia);
        when(feedMedia.getId()).thenReturn((long)1);

        assertTrue(FeedItemMenuHandler.onMenuItemClicked(context, R.id.delete_download,
                feedItem, fragmentManager));
    }
}