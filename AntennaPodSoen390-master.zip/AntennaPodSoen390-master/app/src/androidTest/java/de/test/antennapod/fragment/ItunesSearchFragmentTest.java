package de.test.antennapod.fragment;

import junit.framework.TestCase;

import org.mockito.Mockito;

import de.danoeh.antennapod.fragment.itunes.ItunesSearchFragment;

import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class ItunesSearchFragmentTest extends TestCase {
    ItunesSearchFragment fragment = spy(ItunesSearchFragment.class);
    private String query;

    public void testCategories() throws Exception {
        Mockito.doNothing().when(fragment).loadToplist();
        Mockito.doNothing().when(fragment).search("test");

        fragment.categories(query);
        verify(fragment, times(1)).loadToplist();
        String query = "test";

        fragment.categories(query);
        verify(fragment, times(1)).search(query);
    }

}