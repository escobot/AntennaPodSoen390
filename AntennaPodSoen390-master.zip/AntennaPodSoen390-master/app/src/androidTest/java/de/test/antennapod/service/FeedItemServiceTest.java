package de.test.antennapod.service;

import android.test.InstrumentationTestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.storage.DBReader;
import de.danoeh.antennapod.core.storage.PodDBAdapter;
import de.danoeh.antennapod.core.util.DateUtils;
import de.danoeh.antennapod.service.FeedItemService;

import static de.test.antennapod.storage.DBTestUtils.saveFeedlist;


public class FeedItemServiceTest  extends InstrumentationTestCase {

    @Override
    protected void tearDown() throws Exception {
        // wipe the database after running the tests
        super.tearDown();
        assertTrue(PodDBAdapter.deleteDatabase());
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        // create new database
        PodDBAdapter.init(getInstrumentation().getTargetContext());
        PodDBAdapter.deleteDatabase();
        PodDBAdapter adapter = PodDBAdapter.getInstance();
        adapter.open();
        adapter.close();
    }

    public void testLastPlayedDateDatabaseIntialization() {
        // characterization test

        // Create fake download items
        saveDownloadedItems(5);
        List<FeedItem> feedItems = DBReader.getDownloadedItems();

        for(FeedItem item : feedItems) {
            // assert the fake downloads have a default last played date
            assertNotNull(item.getLastPlayed());
        }
    }

    public void testUpdateLastPlayedDate() {
        // Create fake download items
        saveDownloadedItems(5);
        List<FeedItem> feedItems = DBReader.getDownloadedItems();

        // Ensure that calling FeedItemService updates the date correctly
        List<Date> defaultDates = new ArrayList<>();
        for(FeedItem item : feedItems) {
            // save the default date in arraylist
            defaultDates.add(item.getLastPlayed());

            // update the feed items dates
            FeedItemService.updateLastPlayedDate(item);
        }

        int index = 0;
        Date today = new Date();
        for(FeedItem item: feedItems) {
            // assert the dates are different from the default dates
            assertNotSame(item.getLastPlayed(), defaultDates.get(index));

            // assert the date got updated to today's date
            assertTrue(DateUtils.isSameDay(item.getLastPlayed(), today));
            index++;
        }
    }

    private void saveDownloadedItems(int numItems) {
        if (numItems <= 0) {
            throw new IllegalArgumentException("numItems<=0");
        }
        List<Feed> feeds = saveFeedlist(numItems, numItems, true);
        List<FeedItem> items = new ArrayList<>();
        for (Feed f : feeds) {
            items.addAll(f.getItems());
        }
        List<FeedItem> downloaded = new ArrayList<>();
        Random random = new Random();

        while (downloaded.size() < numItems) {
            int i = random.nextInt(numItems);
            if (!downloaded.contains(items.get(i))) {
                FeedItem item = items.get(i);
                item.getMedia().setDownloaded(true);
                item.getMedia().setFile_url("file" + i);
                downloaded.add(item);
            }
        }
        PodDBAdapter adapter = PodDBAdapter.getInstance();
        adapter.open();
        adapter.setFeedItemlist(downloaded);
        adapter.close();
    }

}