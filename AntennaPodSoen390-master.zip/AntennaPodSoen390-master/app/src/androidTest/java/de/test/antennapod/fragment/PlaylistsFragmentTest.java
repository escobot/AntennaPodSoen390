package de.test.antennapod.fragment;

import junit.framework.TestCase;

import java.util.ArrayList;

import de.danoeh.antennapod.core.playlist.Playlist;
import de.danoeh.antennapod.fragment.PlaylistsFragment;

public class PlaylistsFragmentTest extends TestCase {
    private PlaylistsFragment fragment = PlaylistsFragment.newInstance();
    private Playlist t = new Playlist("t");
    private Playlist t2 = new Playlist("t2");
    private Playlist t3 = new Playlist("t3");

    public void testDeletePlaylistByPlaylistId() throws Exception {
        ArrayList<Playlist> playlistList = new ArrayList<Playlist>();
        playlistList.add(t);
        playlistList.add(t2);
        playlistList.add(t3);
        assertEquals(3, playlistList.size());

        int position = 0;

        for(Playlist p : playlistList){
            if(p.getName().equals(t2.getName())){
               position = playlistList.indexOf(p);
            }
        }
        fragment.deletePlaylist(playlistList, position);

        assertTrue(playlistList.contains(t));
        assertFalse(playlistList.contains(t2));
        assertTrue(playlistList.contains(t3));

        assertEquals(2, playlistList.size());
    }
}