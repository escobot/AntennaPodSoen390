package de.test.antennapod.menuhandler;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.storage.DBReader;
import de.danoeh.antennapod.menuhandler.SubscriptionsSearchHandler;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

public class SubscriptionsSearchHandlerTest extends TestCase {

    private SubscriptionsSearchHandler subscriptionsSearchHandler;

    private Feed subscription1;
    private Feed subscription2;

    @Override
    protected void setUp() throws Exception {
        super.setUp();

        // Create a subscription list
        List<Feed> feedList = new ArrayList<>();

        subscription1 = new Feed();
        subscription1.setTitle("Podcast 123");
        subscription1.setAuthor("John Doe");
        subscription1.setDescription("A great podcast.");
        feedList.add(subscription1);

        subscription2 = new Feed();
        subscription2.setTitle("999 Radio");
        subscription2.setAuthor("Bob");
        subscription2.setDescription("A great radio show.");
        feedList.add(subscription2);

        DBReader.NavDrawerData navDrawerData = mock(DBReader.NavDrawerData.class);
        navDrawerData.feeds = feedList;

        /* Mock a search handler to stub the method 'searchFeedItems'
        Required because FeedSearcher.performSearch needs a real Context that is provided by
        the android framework and therefore cannot be mocked
         */
        List<Feed> filteredSubscriptions = new ArrayList<>();
        subscriptionsSearchHandler = mock(SubscriptionsSearchHandler.class);
        doCallRealMethod().when(subscriptionsSearchHandler).getFilteredSubscriptions();
        doCallRealMethod().when(subscriptionsSearchHandler).setSubscriptions(any());
        doCallRealMethod().when(subscriptionsSearchHandler).setFilteredSubscriptions(any());
        doCallRealMethod().when(subscriptionsSearchHandler).findSubscriptions(any());
        subscriptionsSearchHandler.setSubscriptions(navDrawerData);
        subscriptionsSearchHandler.setFilteredSubscriptions(filteredSubscriptions);
    }

    public void testSearchTitle()  {
        String query = "podcast 12";
        doReturn(false).when(subscriptionsSearchHandler).searchFeedItems(any(), any());
        subscriptionsSearchHandler.findSubscriptions(query);
        assertEquals(subscription1, subscriptionsSearchHandler.getFilteredSubscriptions().get(0));
        assertEquals(1, subscriptionsSearchHandler.getFilteredSubscriptions().size());
    }

    public void testSearchAuthor()  {
        String query = "bob";
        doReturn(false).when(subscriptionsSearchHandler).searchFeedItems(any(), any());
        subscriptionsSearchHandler.findSubscriptions(query);
        assertEquals(subscription2, subscriptionsSearchHandler.getFilteredSubscriptions().get(0));
        assertEquals(1, subscriptionsSearchHandler.getFilteredSubscriptions().size());
    }

    public void testSearchDescription()  {
        String query = "great";
        doReturn(false).when(subscriptionsSearchHandler).searchFeedItems(any(), any());
        subscriptionsSearchHandler.findSubscriptions(query);
        assertEquals(subscription1, subscriptionsSearchHandler.getFilteredSubscriptions().get(0));
        assertEquals(subscription2, subscriptionsSearchHandler.getFilteredSubscriptions().get(1));
        assertEquals(2, subscriptionsSearchHandler.getFilteredSubscriptions().size());
    }

    public void testSearchFailed() {
        String query = "xyz";
        doReturn(false).when(subscriptionsSearchHandler).searchFeedItems(any(), any());
        subscriptionsSearchHandler.findSubscriptions(query);
        assertEquals(0, subscriptionsSearchHandler.getFilteredSubscriptions().size());
    }

    public void testSearchEpisodes() {
        String query = "episode #1";
        doReturn(true).when(subscriptionsSearchHandler).searchFeedItems(any(), any());
        subscriptionsSearchHandler.findSubscriptions(query);
        assertEquals(subscription1, subscriptionsSearchHandler.getFilteredSubscriptions().get(0));
        assertEquals(subscription2, subscriptionsSearchHandler.getFilteredSubscriptions().get(1));
        assertEquals(2, subscriptionsSearchHandler.getFilteredSubscriptions().size());
    }

}