package de.test.antennapod.util;

import android.test.InstrumentationTestCase;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.service.download.DownloadStatus;
import de.danoeh.antennapod.core.storage.DBReader;
import de.danoeh.antennapod.core.storage.PodDBAdapter;
import de.danoeh.antennapod.core.util.DownloadStatusUtil;

import static de.test.antennapod.storage.DBTestUtils.saveFeedlist;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DownloadStatusUtilTest extends InstrumentationTestCase {

    private List<DownloadStatus> downloadStatusList;
    private List<FeedItem> downloaded_saved;
    private DownloadStatus item1;
    private DownloadStatus item2;


    @Override
    protected void tearDown() throws Exception {

        // wipe the database after running the tests
        super.tearDown();
        assertTrue(PodDBAdapter.deleteDatabase());
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();

        // create new database
        PodDBAdapter.init(getInstrumentation().getTargetContext());
        PodDBAdapter.deleteDatabase();
        PodDBAdapter adapter = PodDBAdapter.getInstance();
        adapter.open();
        adapter.close();

        // create mocks
        // Create  2 fake download items
        final int numItems = 2;
        saveDownloadedItems(numItems);
        downloaded_saved = DBReader.getDownloadedItems();

        // Mock download status list
        downloadStatusList = new ArrayList<>();

        // Mock download status objects
        item1 = mock(DownloadStatus.class);
        when(item1.getTitle()).thenReturn(downloaded_saved.get(0).getTitle());
        downloadStatusList.add(item1);

        item2 = mock(DownloadStatus.class);
        when(item2.getTitle()).thenReturn(downloaded_saved.get(1).getTitle());
        downloadStatusList.add(item2);
    }


    public void testGetIds() {
        // This array should contain the ids of the downloaded_saved list
        long[] ids = DownloadStatusUtil.getIds(downloadStatusList);

        // Make an array list containing only the ids of the downloaded_saved list
        ArrayList<Long> other = new ArrayList<>();
        for (FeedItem item : downloaded_saved) {
            other.add(item.getId());
        }

        // verify the ids match on both data structures
        assertTrue(other.contains(ids[0]));
        assertTrue(other.contains(ids[1]));
    }

    private void saveDownloadedItems(int numItems) {
        if (numItems <= 0) {
            throw new IllegalArgumentException("numItems<=0");
        }
        List<Feed> feeds = saveFeedlist(numItems, numItems, true);
        List<FeedItem> items = new ArrayList<>();
        for (Feed f : feeds) {
            items.addAll(f.getItems());
        }
        List<FeedItem> downloaded = new ArrayList<>();
        Random random = new Random();

        while (downloaded.size() < numItems) {
            int i = random.nextInt(numItems);
            if (!downloaded.contains(items.get(i))) {
                FeedItem item = items.get(i);
                item.getMedia().setDownloaded(true);
                item.getMedia().setFile_url("file" + i);
                downloaded.add(item);
            }
        }
        PodDBAdapter adapter = PodDBAdapter.getInstance();
        adapter.open();
        adapter.setFeedItemlist(downloaded);
        adapter.close();
    }

}
