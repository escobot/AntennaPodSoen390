package de.test.antennapod.adapter;

import junit.framework.TestCase;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import de.danoeh.antennapod.adapter.itunes.ItunesCategoriesAdapter;

public class ItunesCategoriesAdapterTest extends TestCase {
    ItunesCategoriesAdapter adapter;
    List<String> testList;

    @Override
    public void setUp() throws Exception {
        super.setUp();
        testList = new ArrayList<>();
        testList.add("one");
        testList.add("two");
        testList.add("three");

        adapter = new ItunesCategoriesAdapter(testList);
    }

    @Test
    public void testGetCount() throws Exception {
        assertEquals(3, adapter.getCount());
        testList.add("four");
        assertEquals(4, adapter.getCount());
        testList.remove(3);
        assertEquals(3, adapter.getCount());
    }

    @Test
    public void testGetItem() throws Exception {
        assertEquals("one", adapter.getItem(0));
        assertEquals("three", adapter.getItem(2));
    }

}