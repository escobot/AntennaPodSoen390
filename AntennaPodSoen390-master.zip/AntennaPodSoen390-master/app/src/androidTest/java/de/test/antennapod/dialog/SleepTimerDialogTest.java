package de.test.antennapod.dialog;

import android.media.MediaPlayer;

import junit.framework.TestCase;

import de.danoeh.antennapod.activity.MediaplayerActivity;
import de.danoeh.antennapod.core.util.playback.PlaybackController;
import de.danoeh.antennapod.dialog.SleepTimerDialog;

import static org.mockito.Mockito.*;
/**
 * Created by Joey on 2018-03-03.
 */
public class SleepTimerDialogTest extends TestCase {


public void testGetSleepTillEnd()
{
    PlaybackController controllerMock = mock(PlaybackController.class);
    when(controllerMock.getDuration()).thenReturn(120000);
    when(controllerMock.getPosition()).thenReturn(60000);
    MediaplayerActivity mediaMock = mock(MediaplayerActivity.class);
    SleepTimerDialog td = new SleepTimerDialog(mediaMock) {
        @Override
        public void onTimerSet(long millis, boolean shakeToReset, boolean vibrate) {
            controllerMock.setSleepTimer(millis, shakeToReset, vibrate);
        }
    };

    assertEquals(1,td.getSleepTillEnd(controllerMock));

}





}