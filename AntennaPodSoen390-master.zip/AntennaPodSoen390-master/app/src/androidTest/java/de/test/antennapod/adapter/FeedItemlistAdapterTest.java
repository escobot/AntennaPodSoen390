package de.test.antennapod.adapter;

import android.test.AndroidTestCase;

/**
 * Created by Joey on 2018-01-28.
 */
public class FeedItemlistAdapterTest extends AndroidTestCase {

    public void setUp() throws Exception {
        super.setUp();
    }

    public void testAssert(){
        assertEquals(0,0);
    }

}