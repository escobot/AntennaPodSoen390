package de.test.antennapod.adapter;

import junit.framework.TestCase;

public class NavListAdapterTest extends TestCase {

    public void setUp() throws Exception {
        super.setUp();
    }

    public void testAssert(){
        assertEquals(0,0);
    }

}