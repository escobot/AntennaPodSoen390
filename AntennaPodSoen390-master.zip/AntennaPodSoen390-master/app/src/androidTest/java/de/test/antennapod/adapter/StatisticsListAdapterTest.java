package de.test.antennapod.adapter;

import android.test.InstrumentationTestCase;

import de.danoeh.antennapod.adapter.StatisticsListAdapter;

public class StatisticsListAdapterTest extends InstrumentationTestCase {

    public void testGetCount(){
        StatisticsListAdapter sla = new StatisticsListAdapter(getInstrumentation().getContext());
        assertEquals(0,sla.getCount()); //Default value should be zero.
    }
}