package de.test.antennapod.activity;

import junit.framework.TestCase;

import de.danoeh.antennapod.activity.MediaplayerActivity;
import de.danoeh.antennapod.core.util.playback.PlaybackController;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MediaplayerActivityTest extends TestCase {

    private MediaplayerActivity mediaplayerActivity = spy(MediaplayerActivity.class);
    private PlaybackController playbackController = mock(PlaybackController.class);

    public void testingSkipToStart() throws Exception {
        mediaplayerActivity.setPlayBackController(playbackController);
        when(mediaplayerActivity.checkController()).thenReturn(false);
        mediaplayerActivity.onSkipToStart();

        verify(playbackController).seekTo(0);
        assertEquals(0,playbackController.getPosition());
    }
}