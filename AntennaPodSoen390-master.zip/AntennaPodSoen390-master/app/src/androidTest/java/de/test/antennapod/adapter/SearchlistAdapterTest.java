package de.test.antennapod.adapter;

import android.test.AndroidTestCase;

public class SearchlistAdapterTest extends AndroidTestCase {

    public void setUp() throws Exception {
        super.setUp();
    }

    public void testAssert(){
        assertEquals(0,0);
    }
}