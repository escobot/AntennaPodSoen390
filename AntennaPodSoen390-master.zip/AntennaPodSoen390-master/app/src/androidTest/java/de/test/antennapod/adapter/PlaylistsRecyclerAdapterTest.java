package de.test.antennapod.adapter;

import android.content.Context;

import junit.framework.TestCase;

import java.util.ArrayList;

import de.danoeh.antennapod.adapter.PlaylistsRecyclerAdapter;
import de.danoeh.antennapod.core.playlist.Playlist;

/**
 * Created by Emanuel on 2018-02-10.
 */
public class PlaylistsRecyclerAdapterTest extends TestCase {

    public void testGetItemCount() throws Exception {
        ArrayList<Playlist> playlists = new ArrayList<Playlist>();

        PlaylistsRecyclerAdapter pra = new PlaylistsRecyclerAdapter(playlists);
        assertEquals(0, pra.getItemCount()); //expected value is 0 for default
    }
}