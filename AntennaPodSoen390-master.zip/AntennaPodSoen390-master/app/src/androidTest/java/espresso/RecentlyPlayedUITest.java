package espresso;

import android.support.test.espresso.DataInteraction;
import android.support.test.espresso.UiController;
import android.support.test.espresso.ViewAction;
import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsInstanceOf;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import de.danoeh.antennapod.R;
import de.danoeh.antennapod.activity.SplashActivity;
import de.danoeh.antennapod.core.feed.Feed;
import de.danoeh.antennapod.core.feed.FeedItem;
import de.danoeh.antennapod.core.storage.PodDBAdapter;
import de.danoeh.antennapod.core.util.DateUtils;
import de.danoeh.antennapod.core.util.comparator.FeedItemLastPlayedComparator;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.pressImeActionButton;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withClassName;
import static android.support.test.espresso.matcher.ViewMatchers.withContentDescription;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static de.test.antennapod.storage.DBTestUtils.saveFeedlist;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.is;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class RecentlyPlayedUITest {

    @Rule
    public ActivityTestRule<SplashActivity> mActivityTestRule = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void recentlyPlayedTest() {
        Calendar cal = new GregorianCalendar(2018, 12, 31);
        Date today = cal.getTime();
        saveRecentlyPlayedItems(1,true,today);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction appCompatImageButton2 = onView(
                allOf(withContentDescription("Open menu"),
                        childAtPosition(
                                allOf(withId(R.id.toolbar),
                                        childAtPosition(
                                                withId(R.id.content),
                                                1)),
                                1),
                        isDisplayed()));
        appCompatImageButton2.perform(click());

        DataInteraction relativeLayout3 = onData(anything())
                .inAdapterView(allOf(withId(R.id.nav_list),
                        childAtPosition(
                                withId(R.id.nav_layout),
                                2)))
                .atPosition(7);
        relativeLayout3.perform(click());

        ViewInteraction tabView2 = onView(
                allOf(childAtPosition(
                        childAtPosition(
                                withId(R.id.sliding_tabs),
                                0),
                        0),
                        isDisplayed()));
        tabView2.perform(click());

        ViewInteraction textView = onView(
                allOf(withId(R.id.txtvLastPlayedDate), withText("Last played: Jan 31"),
                        childAtPosition(
                                childAtPosition(
                                        IsInstanceOf.<View>instanceOf(android.widget.LinearLayout.class),
                                        0),
                                2),
                        isDisplayed()));
        textView.check(matches(withText("Last played: Jan 31")));

        PodDBAdapter.deleteDatabase();

    }

    private static Matcher<View> childAtPosition(final Matcher<View> parentMatcher, final int position) {
        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }

    private void saveRecentlyPlayedItems(int numItems, boolean recentlyPlayed, Date rightNow) {
        if (numItems <= 0) {
            throw new IllegalArgumentException("numItems<=0");
        }
        List<Feed> feeds = saveFeedlist(numItems, numItems, true);
        List<FeedItem> items = new ArrayList<>();
        for (Feed f : feeds) {
            items.addAll(f.getItems());
        }
        List<FeedItem> feedItems = new ArrayList<>();
        Random random = new Random();

        if (recentlyPlayed) {
            while (feedItems.size() < numItems) {
                int i = random.nextInt(numItems);
                if (!feedItems.contains(items.get(i))) {
                    FeedItem item = items.get(i);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(rightNow);
                    cal.add(Calendar.DAY_OF_YEAR,-1);
                    Date yesterday = cal.getTime();
                    item.setLastPlayed(rightNow);
                    item.setPubDate(yesterday);
                    item.getMedia().setDownloaded(true);
                    item.getMedia().setFile_url("file" + i);
                    feedItems.add(item);
                }
            }
        } else {
            while (feedItems.size() < numItems) {
                int i = random.nextInt(numItems);
                if (!feedItems.contains(items.get(i))) {
                    FeedItem item = items.get(i);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(rightNow);
                    cal.add(Calendar.YEAR,-50);
                    Date defaultDate = cal.getTime();
                    item.setLastPlayed(defaultDate);
                    item.setPubDate(rightNow);
                    item.getMedia().setDownloaded(true);
                    item.getMedia().setFile_url("file" + i);
                    feedItems.add(item);
                }
            }
        }

        // algorithm used to filtered feeds with default played date
        for (Iterator<FeedItem> itr = feedItems.listIterator(); itr.hasNext(); ) {
            // remove the feed items that have a default last played date
            if (itr.next().getLastPlayed().getYear() < 118) {
                itr.remove();
            }
        }
        Collections.sort(feedItems, new FeedItemLastPlayedComparator());

        PodDBAdapter adapter = PodDBAdapter.getInstance();
        adapter.open();
        adapter.setFeedItemlist(feedItems);
        adapter.close();
    }

}
